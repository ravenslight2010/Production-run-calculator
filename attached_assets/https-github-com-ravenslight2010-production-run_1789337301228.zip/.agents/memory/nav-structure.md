---
name: Web+mobile navigation structure
description: The agreed 6-tab + header-menu layout shared by both run-calculator apps; what belongs where.
---

# Navigation structure (web + mobile parity)

Both `run-calculator` (web) and `run-calculator-mobile` use the SAME navigation: 6 bottom tabs + a header menu. Any nav change must be mirrored in both.

**Bottom tabs:** Run (current + upcoming runs), Dough/Crusts (supply steppers + dough/crust output), Sauce (sauce needs), Frontline (applicator + pepperoni needs), Packaging (packaging steppers + freezer + output), Warehouse (aggregated needs across all not-ended runs + production schedule).

**Header menu (dropdown/sheet, not a tab):** Stoppages, Summary, Stock (inventory), Schedule (supervisor-only on web), Setup (per-run config + recipe editors + templates), Settings (app-level: supervisor PIN, master data, reset).

**Rule:** the bottom bar stays at exactly 6 tabs. New top-level destinations (e.g. Inventory/Stock) go in the header menu, NOT a 7th tab — adding a 7th tab is a spec violation. On web that's a `setActiveTab(...)` DropdownMenuItem with a `TabsContent` panel but no `TabsTrigger`; on mobile it's a `(tabs)/` screen with `options={{ href: null }}` plus a `MENU_ITEMS` entry that `router.push`es to it.

**Why:** User explicitly wanted both apps identical in layout. Calculations/formulas, RunContext sync, and stored state shape must stay unchanged — this is purely a UI reorg.

**Consolidated surfaces (Manage Lists + header menu):** Import (Spec Sheet + Excel), Rules (ProductionRulesManager), and Staff (StaffRolesCard + RolesManager) all live INSIDE Manage Lists, not as standalone cards/screens. Gating mirrors web capabilities: Import always; Rules = `hasCapability("edit-production-rules")` (NOT isManager — parity bug if you use isManager on mobile); Staff = `manage-staff || approve-password-resets`. Change Password is a header-menu "Password" item (web dialog / mobile `(tabs)/password.tsx` screen). The pending-reset nav badge sits on the Settings menu item (since approvals moved into Manage Lists). The general schedule import was consolidated here, but the contextual schedule-editor "Import Excel" (imports INTO the open day editor) intentionally stays on the Schedule screen in both apps.

**How to apply (web specifics):**
- Web is a single `Tabs value={activeTab}` system inside `src/pages/home.tsx`. Tabs are switched via `activeTab` state, NOT URLs.
- Settings is NOT a TabsContent panel — it reuses the existing "Manage Lists & Settings" dialog (`setShowManageDialog(true)`). Manage Lists has a third `settingsTabs` group (`manageCategory` import/rules/staff) alongside the list tabs; these keys are excluded from the Recent-changes footer.
- There are intentionally TWO `TabsContent value="setup"` panels (gated `isSupervisor` vs `!isSupervisor`); Radix renders both but their content is mutually exclusive. Do NOT add overlapping RHF-bound fields across panels — moved steppers must appear once only (double-registration corrupts form state).
