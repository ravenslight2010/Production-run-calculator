import { db, dailySyncTable } from "@workspace/db";
import { and, eq } from "drizzle-orm";

// The daily reset doubles as a session boundary: when a client performs the
// midnight rollover it records the reset on today's `daily_sync` row (via the
// sync endpoints). Any auth token issued before that timestamp is treated as
// signed out, so the whole shift is forced to re-authenticate for the new
// production day — enforced here, server-side, so it applies to every device
// regardless of which one detected midnight.
//
// We read the fence from `dayState.resetBoundaryAt`, NOT `dayState.resetAt`.
// `resetAt` is also stamped on FUTURE-day writes (to trigger the scheduling
// wholesale-adopt merge) and is keyed to the CLIENT's local calendar — so a user
// behind UTC stamps their "tomorrow", which can equal the SERVER's UTC "today".
// Reading `resetAt` here therefore logged the whole shift out hours before their
// real local midnight. `resetBoundaryAt` is set (server-side) ONLY when a row is
// written as the writer's actual current local day, so only a genuine same-day
// rollover can fence sessions (see applyResetBoundary in routes/sync.ts).
//
// We read only today's row (primary-key lookup) and cache the value briefly so
// requireAuth, which runs on every request including SSE, never pays for a DB
// round-trip per request.

function todayStr(): string {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

const CACHE_TTL_MS = 15_000;
let cachedBoundaryMs = 0;
let cachedAt = 0;

// Returns the current daily-reset boundary as a millisecond epoch (0 when no
// reset has been recorded for today yet, meaning no token is fenced out).
export async function getSessionBoundaryMs(): Promise<number> {
  const now = Date.now();
  if (now - cachedAt < CACHE_TTL_MS) return cachedBoundaryMs;
  try {
    // Pinned to the live scope: the daily-reset boundary is a single global
    // fence for the whole shift. (daily_sync is now keyed by date+scope, so an
    // unscoped lookup would return multiple rows.)
    const [row] = await db
      .select()
      .from(dailySyncTable)
      .where(and(eq(dailySyncTable.date, todayStr()), eq(dailySyncTable.scope, "live")));
    const data = row?.data as
      | { dayState?: { resetBoundaryAt?: unknown } }
      | null
      | undefined;
    const boundary = data?.dayState?.resetBoundaryAt;
    cachedBoundaryMs =
      typeof boundary === "number" && boundary > 0 ? boundary : 0;
    cachedAt = now;
    return cachedBoundaryMs;
  } catch {
    // On a transient DB error, fail open to the last known boundary rather than
    // logging everyone out; cachedAt is left unchanged so the next request
    // retries the read promptly.
    return cachedBoundaryMs;
  }
}

// Drops the cached boundary so the next read hits the database. Intended for
// tests, which set up distinct daily_sync rows per case against this shared
// module-level cache; production never needs it (the cache simply ages out).
export function clearSessionBoundaryCache(): void {
  cachedBoundaryMs = 0;
  cachedAt = 0;
}
