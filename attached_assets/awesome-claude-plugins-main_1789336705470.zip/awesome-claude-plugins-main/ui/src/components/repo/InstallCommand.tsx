'use client'

import { useInstallCommand } from '../../hooks/useInstallCommand.ts'
import { CopiedIcon } from '../common/CopiedIcon.tsx'
import { CopyIcon } from '../common/CopyIcon.tsx'

interface InstallCommandProps {
  pluginName?: string
  pluginId?: string
  repoPath: string
}

export function InstallCommand({ pluginName, pluginId, repoPath }: InstallCommandProps) {
  const { copyError, handleCopyClick, installCommand, isCopied, isVerified } = useInstallCommand(pluginName, pluginId, repoPath)

  const isDisabled = !(installCommand && isVerified)

  return (
    <div className="px-6 pb-4">
      <div className="flex items-center gap-2 rounded-md border bg-muted/50 p-3">
        <code className="grow break-all font-mono text-sm">{installCommand ?? 'Install command unavailable'}</code>
        {installCommand && !isVerified && <span className="shrink-0 text-muted-foreground text-xs">unverified</span>}
        <button
          aria-label={
            isCopied ? 'Installation command copied' : isDisabled ? 'Copy install command unavailable' : 'Copy installation command'
          }
          className={`touch-target shrink-0 rounded-md p-1 transition-colors disabled:cursor-not-allowed disabled:opacity-50 ${isCopied ? 'bg-status-positive/20 text-status-positive' : 'enabled:hover:bg-muted'}`}
          disabled={isDisabled}
          onClick={handleCopyClick}
          title={isVerified ? 'Copy installation command' : 'Unverified command'}
          type="button"
        >
          {isCopied ? <CopiedIcon /> : <CopyIcon />}
        </button>
      </div>
      <p aria-live="polite" className="mt-2 text-destructive text-xs" role={copyError ? 'alert' : undefined}>
        {copyError ?? (isCopied ? 'Install command copied.' : '')}
      </p>
    </div>
  )
}
