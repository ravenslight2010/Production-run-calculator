import { CircleDot, Code, ExternalLink, Eye, FileText, GitFork, Star } from 'lucide-react'
import Image from 'next/image'
import { formatDate as formatDateUtil } from '../../lib/utils.ts'
import type { GitHubRepository } from '../../schemas/github.schema.ts'
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar.tsx'
import { Badge } from '../ui/badge.tsx'
import { Button } from '../ui/button.tsx'
import { Card, CardContent, CardDescription, CardHeader } from '../ui/card.tsx'

function getSafeHomepageUrl(homepage: string | null): string | null {
  if (!homepage) return null

  try {
    const url = new URL(homepage)
    return url.protocol === 'https:' || url.protocol === 'http:' ? url.toString() : null
  } catch {
    return null
  }
}

interface RepoInfoCardProps {
  repo: GitHubRepository
}

export function RepoInfoCard({ repo }: RepoInfoCardProps) {
  const homepageUrl = getSafeHomepageUrl(repo.homepage)
  const formatDate = (dateString: string | null) => {
    if (!dateString) return 'Unknown'
    return formatDateUtil(new Date(dateString))
  }

  const formatSize = (size: number | null) => {
    if (size === null || size === undefined) return 'Unknown'
    const kb = size
    if (kb < 1024) return `${kb} KB`
    const mb = kb / 1024
    return `${mb.toFixed(1)} MB`
  }

  return (
    <Card className="p-4 sm:p-8">
      <CardHeader className="mb-0 p-0">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
          <div className="flex items-start gap-4">
            <Avatar className="h-12 w-12 sm:h-16 sm:w-16">
              <AvatarImage asChild>
                <Image alt={repo.owner.login} height={64} src={repo.owner.avatar_url} width={64} />
              </AvatarImage>
              <AvatarFallback>{repo.owner.login.slice(0, 2).toUpperCase()}</AvatarFallback>
            </Avatar>
            <div className="min-w-0 flex-1">
              <h1 className="wrap-break-word mb-2 text-balance font-bold text-2xl sm:text-3xl">{repo.name}</h1>
              <CardDescription className="wrap-break-word text-base sm:text-lg">
                by{' '}
                <a
                  aria-label={`View ${repo.owner.login}'s GitHub profile`}
                  className="underline-offset-4 hover:text-primary hover:underline"
                  href={repo.owner.html_url}
                  rel="noopener noreferrer"
                  target="_blank"
                >
                  {repo.owner.login}
                </a>
              </CardDescription>
            </div>
          </div>
          <div className="flex flex-col gap-2 sm:ml-4 sm:flex-row sm:flex-nowrap sm:gap-3">
            {homepageUrl && (
              <Button asChild className="flex-1 justify-center sm:w-auto" variant="outline">
                <a aria-label="Visit repository homepage" href={homepageUrl} rel="nofollow noopener noreferrer" target="_blank">
                  <ExternalLink aria-hidden="true" className="h-4 w-4" />
                  Homepage
                </a>
              </Button>
            )}
            <Button asChild className="flex-1 justify-center sm:w-auto">
              <a
                aria-label={`View ${repo.owner.login}/${repo.name} on GitHub`}
                href={repo.html_url}
                rel="noopener noreferrer"
                target="_blank"
              >
                <ExternalLink aria-hidden="true" className="h-4 w-4" />
                View on GitHub
              </a>
            </Button>
          </div>
        </div>
      </CardHeader>

      <CardContent className="p-0">
        {!!repo.description && <p className="mb-6 text-base text-muted-foreground sm:text-lg">{repo.description}</p>}

        <div className="mb-6 flex flex-wrap gap-3 sm:gap-4">
          <Badge className="gap-2 text-sm" variant="secondary">
            <Star aria-hidden="true" className="h-5 w-5" />
            <span className="font-semibold">{repo.stargazers_count?.toLocaleString() ?? 0}</span>
            <span>stars</span>
          </Badge>
          <Badge className="gap-2 text-sm" variant="secondary">
            <GitFork aria-hidden="true" className="h-5 w-5" />
            <span className="font-semibold">{repo.forks_count?.toLocaleString() ?? 0}</span>
            <span>forks</span>
          </Badge>
          <Badge className="gap-2 text-sm" variant="secondary">
            <Eye aria-hidden="true" className="h-5 w-5" />
            <span className="font-semibold">{repo.subscribers_count?.toLocaleString() ?? 0}</span>
            <span>watchers/subscribers</span>
          </Badge>
          <Badge className="gap-2 text-sm" variant="secondary">
            <CircleDot aria-hidden="true" className="h-5 w-5" />
            <span className="font-semibold">{repo.open_issues_count?.toLocaleString() ?? 0}</span>
            <span>issues</span>
          </Badge>
        </div>

        {!!repo.topics && repo.topics.length > 0 && (
          <div className="mb-6 flex flex-wrap gap-2">
            {repo.topics.map((topic) => (
              <Badge key={topic} variant="outline">
                {topic}
              </Badge>
            ))}
          </div>
        )}

        <dl className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {!!repo.language && (
            <div>
              <dt className="flex items-center gap-2 font-medium text-muted-foreground text-sm">
                <Code className="h-4 w-4" />
                Language
              </dt>
              <dd className="text-foreground">{repo.language}</dd>
            </div>
          )}
          {!!repo.license && (
            <div>
              <dt className="flex items-center gap-2 font-medium text-muted-foreground text-sm">
                <FileText className="h-4 w-4" />
                License
              </dt>
              <dd className="text-foreground">{repo.license.name}</dd>
            </div>
          )}
          <div>
            <dt className="font-medium text-muted-foreground text-sm">Size</dt>
            <dd className="text-foreground">{formatSize(repo.size)}</dd>
          </div>
          <div>
            <dt className="font-medium text-muted-foreground text-sm">Created</dt>
            <dd className="text-foreground">{formatDate(repo.created_at)}</dd>
          </div>
          <div>
            <dt className="font-medium text-muted-foreground text-sm">Last Updated</dt>
            <dd className="text-foreground">{formatDate(repo.updated_at)}</dd>
          </div>
          <div>
            <dt className="font-medium text-muted-foreground text-sm">Last Pushed</dt>
            <dd className="text-foreground">{formatDate(repo.pushed_at)}</dd>
          </div>
        </dl>
      </CardContent>
    </Card>
  )
}
