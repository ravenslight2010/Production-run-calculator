"""Shared utilities for hooks."""
