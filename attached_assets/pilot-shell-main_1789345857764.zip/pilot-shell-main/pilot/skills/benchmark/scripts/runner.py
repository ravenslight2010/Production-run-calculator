#!/usr/bin/env python3
"""Unified benchmark runner — orchestrates with/without comparison runs.

Handles two target types:
    skill  — installs the target skill under `.claude/skills/<name>/` for
             Claude or `.agents/skills/<name>/` for Codex
    rules  — copies rule file(s) into `.claude/rules/` for Claude or composes
             root `AGENTS.md` for Codex

Both configs materialize an explicit agent config surface under /tmp/pilot-bench-*/
so project discovery stops there and never walks UP into a parent repo. Each
`claude -p` subprocess writes a stream-json transcript; the final `result` event
supplies duration_ms + usage (token counts).
Missing those required fields → run is marked FAILED rather than silently zeroed.
"""

from __future__ import annotations

import argparse
import atexit
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from scripts.isolation import (
    detect_global_contamination,
    install_signal_handlers,
    isolate_global_contamination,
    recover_stale_manifests,
)
from scripts.progress import PlanHeader, ProgressReporter, render_plan_header
from scripts.utils import (
    DEFAULT_FALLBACK_MODEL,
    EvalSpec,
    ExecuteFailure,
    ExecuteResult,
    ExecuteSuccess,
    GraderFailure,
    GraderResult,
    GraderSuccess,
    ParsedResult,
    ResultEvent,
    TargetConfig,
    load_target_config,
    resolve_executor_model,
    strip_conditional_loading_frontmatter,
)


@dataclass(frozen=True, slots=True)
class RunConfig:
    """Bundled runtime parameters that apply to every eval × config × run."""

    runs: int
    model: str
    grader_model: str
    timeout: int
    grader_timeout: int
    skip_permissions: bool = False
    agent: str = "claude"
    grader_agent: str = "claude"
    eval_selectors: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class RunSpec:
    """One unit of pool work: a single (eval, config, run_idx) triple."""

    eval_obj: EvalSpec
    config_kind: str
    run_idx: int


__version__ = "0.1.0"

REQUIRED_RESULT_FIELDS = ("duration_ms", "usage")
TEMP_DIRS: list[Path] = []

SANDBOX_PLACEHOLDER = "{sandbox}"
CODEX_DEFAULT_MODEL = "codex-default"


def _codex_exec_command() -> list[str]:
    """Return an unwrapped Codex command isolated from personal configuration."""
    codex_bin = os.environ.get("PILOT_BENCH_CODEX_BIN", "codex")
    return [
        codex_bin,
        "exec",
        "--skip-git-repo-check",
        "--ephemeral",
        "--ignore-user-config",
        "--ignore-rules",
    ]


def _resolve_run_models(
    *,
    agent: str,
    grader_agent: str,
    model_arg: str | None,
    grader_model_arg: str | None,
    target: TargetConfig,
) -> tuple[str, str]:
    """Resolve executor and grader models without leaking agent-specific sentinels."""
    executor_model = model_arg or (CODEX_DEFAULT_MODEL if agent == "codex" else resolve_executor_model(target))
    if grader_model_arg:
        return executor_model, grader_model_arg
    if grader_agent == agent:
        return executor_model, executor_model
    if grader_agent == "codex":
        return executor_model, CODEX_DEFAULT_MODEL
    return executor_model, resolve_executor_model(target)


def substitute_sandbox(prompt: str, sandbox_path: Path) -> str:
    """Replace {sandbox} in the prompt with the per-run isolated directory.

    This is the safe way for evals.json to reference filesystem paths — the path
    is unique per (eval, config, run) so concurrent or sequential runs can never
    read each other's outputs.
    """
    return prompt.replace(SANDBOX_PLACEHOLDER, str(sandbox_path))


def validate_prompt_isolation(prompt: str) -> str | None:
    """Return a warning string if the prompt hardcodes shared filesystem paths.

    Returns None when the prompt looks safe. Flags prompts that reference
    `/tmp/` without using {sandbox} — those paths are shared across `with`/
    `without` runs and cause the two configs to read each other's outputs,
    which produces false-positive pass rates.
    """
    if SANDBOX_PLACEHOLDER in prompt:
        return None
    if "/tmp/" not in prompt:
        return None
    return (
        "prompt references hardcoded `/tmp/...` paths without using "
        f"`{SANDBOX_PLACEHOLDER}` — the `with` and `without` runs will share "
        "these paths and contaminate each other. Either use relative paths "
        f"(cwd is already per-run isolated) or substitute `{SANDBOX_PLACEHOLDER}` "
        "so each run gets a unique directory."
    )


def _cleanup_temp_dirs() -> None:
    for path in TEMP_DIRS:
        shutil.rmtree(path, ignore_errors=True)


atexit.register(_cleanup_temp_dirs)


def parse_result_event(event: ResultEvent) -> ParsedResult:
    """Parse the final `result` event into a normalized timing dict.

    Raises ValueError if the event is not a result or required fields are missing.
    """
    if event.get("type") != "result":
        raise ValueError("not a result event")
    missing = [k for k in REQUIRED_RESULT_FIELDS if k not in event]
    if missing:
        raise ValueError(f"result event missing required fields: {missing}")

    usage = event.get("usage") or {}
    input_tokens = usage.get("input_tokens", 0)
    output_tokens = usage.get("output_tokens", 0)
    cache_creation = usage.get("cache_creation_input_tokens", 0)
    cache_read = usage.get("cache_read_input_tokens", 0)

    duration_ms = event.get("duration_ms")
    if duration_ms is None:
        raise ValueError("result event missing duration_ms")
    return ParsedResult(
        duration_ms=duration_ms,
        duration_api_ms=event.get("duration_api_ms"),
        input_tokens=input_tokens,
        output_tokens=output_tokens,
        cache_creation_input_tokens=cache_creation,
        cache_read_input_tokens=cache_read,
        total_tokens=input_tokens + output_tokens + cache_creation + cache_read,
        total_cost_usd=event.get("total_cost_usd"),
        is_error=event.get("is_error", False),
        result_text=event.get("result", ""),
        stop_reason=event.get("stop_reason"),
        session_id=event.get("session_id"),
    )


def extract_final_result_event(lines: list[str]) -> ResultEvent | None:
    """Find the final `result` JSON event from a stream-json transcript.

    Tolerates malformed lines and non-JSON noise.
    """
    last_result = None
    for line in lines:
        line = line.strip()
        if not line:
            continue
        try:
            obj = json.loads(line)
        except json.JSONDecodeError:
            continue
        if obj.get("type") == "result":
            last_result = obj
    return last_result


def _safe_prefixes() -> tuple[Path, ...]:
    """Return the set of filesystem prefixes where target.path is allowed to live.

    Evaluated at runtime so /tmp resolves correctly (macOS /tmp → /private/tmp).
    """
    prefixes = [Path.home().resolve(), Path("/tmp").resolve()]
    var_folders = Path("/var/folders")
    if var_folders.exists():
        prefixes.append(var_folders.resolve())
    return tuple(prefixes)


def _validate_target_path(source_path: Path) -> None:
    """Reject paths that look like traversal attacks.

    We allow absolute paths (users legitimately benchmark skills anywhere on their
    system) but reject paths that are siblings of sensitive root dirs. The real
    risk is a malicious committed evals.json — guard against that by requiring the
    resolved path to be within the user's home tree or /tmp.
    """
    try:
        resolved = source_path.resolve()
    except OSError:
        raise ValueError(f"target.path could not be resolved: {source_path}")

    safe = any((resolved == p or resolved.is_relative_to(p)) for p in _safe_prefixes())
    if not safe:
        raise ValueError(
            f"target.path resolves outside approved locations: {resolved}\n"
            "Expected a path under your home directory or /tmp. "
            "If intentional, pass an approved location explicitly."
        )


_SKILL_FRONTMATTER_FILES: tuple[str, ...] = ("SKILL.md", "orchestrator.md")


def _resolve_skill_resource(skill_dir: Path, value: object, label: str) -> Path:
    """Resolve one manifest resource without allowing a path or symlink escape."""
    if not isinstance(value, str) or not value or "\\" in value or "\x00" in value or ":" in value:
        raise ValueError(f"{label} must be a normalized relative path")
    relative = Path(value)
    if relative.is_absolute() or any(part in {"", ".", ".."} for part in relative.parts):
        raise ValueError(f"{label} must be a normalized relative path")
    root = skill_dir.resolve()
    candidate = (skill_dir / relative).resolve()
    if not candidate.is_relative_to(root) or not candidate.is_file():
        raise ValueError(f"{label} is missing or resolves outside the skill: {value}")
    return candidate


def _materialize_decomposed_skill(skill_dir: Path, *, agent: str, skill_name: str) -> None:
    """Build SKILL.md inside a copied manifest-based skill benchmark fixture."""
    target = skill_dir / "SKILL.md"
    if target.is_file():
        return
    manifest_path = skill_dir / "manifest.json"
    orchestrator_path = skill_dir / "orchestrator.md"
    if not manifest_path.is_file() or not orchestrator_path.is_file():
        return
    try:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ValueError(f"cannot read decomposed skill manifest: {exc}") from exc
    steps = manifest.get("steps")
    if not isinstance(steps, list):
        raise ValueError("decomposed skill manifest.steps must be an array")
    orchestrator = _resolve_skill_resource(skill_dir, manifest.get("orchestrator"), "manifest.orchestrator")
    parts = [orchestrator.read_text(encoding="utf-8")]
    delivery = manifest.get("delivery", "bundled")
    for index, step in enumerate(steps, start=1):
        if not isinstance(step, dict) or not isinstance(step.get("id"), str):
            raise ValueError(f"manifest step {index} must have string id and file")
        resource = _resolve_skill_resource(skill_dir, step.get("file"), f"manifest step {index}")
        if delivery == "bundled":
            parts.append(resource.read_text(encoding="utf-8"))
    if delivery == "progressive":
        phase_lines = [
            "## Required phase resources",
            "",
            "Follow these phases in order. Read each referenced file completely at the named point.",
            "",
        ]
        for index, step in enumerate(steps, start=1):
            phase_lines.append(
                f"{index}. **{step['id']}** — Read `{step['file']}` completely, then execute this phase before continuing."
            )
        parts.append("\n".join(phase_lines))
    elif delivery != "bundled":
        raise ValueError(f"unsupported skill delivery: {delivery!r}")
    content = "\n\n".join(part.strip() for part in parts if part.strip()).rstrip() + "\n"
    if agent == "codex":
        content = re.sub(
            rf"(?<![a-zA-Z0-9_/])/{re.escape(skill_name)}(?![a-zA-Z0-9_/])",
            f"${skill_name}",
            content,
        )
    target.write_text(content, encoding="utf-8")


def _copy_md_stripping_conditional(src: Path, dest: Path) -> None:
    """Copy a markdown file, removing path/paths frontmatter so the rule loads
    unconditionally during the benchmark. Falls back to a plain copy when the
    source has no conditional fields."""
    try:
        content = src.read_text()
    except OSError:
        shutil.copy2(src, dest)
        return
    stripped, removed = strip_conditional_loading_frontmatter(content)
    if removed:
        dest.write_text(stripped)
        try:
            shutil.copystat(src, dest)
        except OSError:
            pass
    else:
        shutil.copy2(src, dest)


def _read_md_stripping_conditional(src: Path) -> str:
    """Read markdown, removing conditional-loading fields when present."""
    content = src.read_text()
    stripped, removed = strip_conditional_loading_frontmatter(content)
    return stripped if removed else content


def _strip_skill_frontmatter_in_place(skill_dir: Path) -> None:
    """After copytree, strip conditional-loading fields from SKILL.md /
    orchestrator.md so the skill activates for every prompt during the run."""
    for name in _SKILL_FRONTMATTER_FILES:
        path = skill_dir / name
        if not path.exists():
            continue
        try:
            content = path.read_text()
        except OSError:
            continue
        stripped, removed = strip_conditional_loading_frontmatter(content)
        if removed:
            path.write_text(stripped)


def detect_conditional_loading(target: TargetConfig) -> list[tuple[Path, list[str]]]:
    """Return ``[(file, [fields])]`` for target files that will be stripped.

    Used solely to print a one-line announcement before the worker pool starts;
    the actual stripping happens inside ``prepare_config_dir`` per worker.
    """
    target_type = target.get("type", "skill")
    raw_path = target.get("path")
    if not raw_path:
        return []
    source_path = Path(raw_path).expanduser().resolve()
    if not source_path.exists():
        return []

    candidates: list[Path] = []
    if target_type == "rules":
        candidates = [source_path] if source_path.is_file() else list(source_path.rglob("*.md"))
    elif target_type == "skill":
        for name in _SKILL_FRONTMATTER_FILES:
            candidate = source_path / name
            if candidate.exists():
                candidates.append(candidate)

    findings: list[tuple[Path, list[str]]] = []
    for path in candidates:
        try:
            content = path.read_text()
        except OSError:
            continue
        _, removed = strip_conditional_loading_frontmatter(content)
        if removed:
            findings.append((path, removed))
    return findings


def _prepare_codex_config_dir(target: TargetConfig, config_kind: str, tmp_root: Path) -> Path:
    """Create an ephemeral Codex project dir for the config."""
    dest = tmp_root / config_kind
    dest.mkdir(parents=True, exist_ok=True)
    agents_md = dest / "AGENTS.md"
    agents_md.write_text("# Benchmark Baseline\n\n")

    if config_kind == "without":
        return dest

    target_type = target.get("type", "skill")
    raw_path = target.get("path")
    if not raw_path:
        raise ValueError("target.path is required when config_kind is 'with'")
    source_path = Path(raw_path).expanduser().resolve()
    _validate_target_path(source_path)
    if not source_path.exists():
        raise FileNotFoundError(f"target.path does not exist: {source_path}")

    if target_type == "skill":
        skill_name = target.get("name") or source_path.name
        skills_dir = dest / ".agents" / "skills" / skill_name
        shutil.copytree(source_path, skills_dir)
        _materialize_decomposed_skill(skills_dir, agent="codex", skill_name=skill_name)
        _strip_skill_frontmatter_in_place(skills_dir)
    elif target_type == "rules":
        sources = [source_path] if source_path.is_file() else sorted(source_path.rglob("*.md"))
        blocks = ["# Benchmark Rules", ""]
        for md in sources:
            blocks.extend([f"## {md.stem}", "", _read_md_stripping_conditional(md).strip(), ""])
        agents_md.write_text("\n".join(blocks).rstrip() + "\n")
    else:
        raise ValueError(f"unsupported target type: {target_type}")

    return dest


def prepare_config_dir(
    target: TargetConfig,
    config_kind: str,
    tmp_root: Path,
    agent: str = "claude",
) -> Path:
    """Create an ephemeral project dir with agent-specific config populated.

    `config_kind` is "with" or "without".
    Returns the path to the project directory the subprocess will use as cwd.

    For the ``with`` config, ``path:``/``paths:`` frontmatter fields are stripped
    from the installed copy so conditional-loading rules and skills activate
    unconditionally during the benchmark (otherwise the rule may be dormant in
    both configs and the delta collapses to zero).
    """
    if agent == "codex":
        return _prepare_codex_config_dir(target, config_kind, tmp_root)

    dest = tmp_root / config_kind
    dest.mkdir(parents=True, exist_ok=True)
    claude_dir = dest / ".claude"
    claude_dir.mkdir(exist_ok=True)

    if config_kind == "without":
        return dest

    target_type = target.get("type", "skill")
    raw_path = target.get("path")
    if not raw_path:
        raise ValueError("target.path is required when config_kind is 'with'")
    source_path = Path(raw_path).expanduser().resolve()
    _validate_target_path(source_path)
    if not source_path.exists():
        raise FileNotFoundError(f"target.path does not exist: {source_path}")

    if target_type == "skill":
        skill_name = target.get("name") or source_path.name
        skills_dir = claude_dir / "skills" / skill_name
        shutil.copytree(source_path, skills_dir)
        _materialize_decomposed_skill(skills_dir, agent="claude", skill_name=skill_name)
        _strip_skill_frontmatter_in_place(skills_dir)
    elif target_type == "rules":
        rules_dir = claude_dir / "rules"
        rules_dir.mkdir(exist_ok=True)
        if source_path.is_file():
            _copy_md_stripping_conditional(source_path, rules_dir / source_path.name)
        else:
            for md in source_path.rglob("*.md"):
                _copy_md_stripping_conditional(md, rules_dir / md.name)
    else:
        raise ValueError(f"unsupported target type: {target_type}")

    return dest


def _make_subprocess_env(agent: str = "claude") -> dict[str, str]:
    """Strip nesting and parent-session state from isolated agent runs."""
    skip = {"CLAUDECODE"} if agent == "claude" else {"CODEX_SANDBOX_TYPE", "CODEX_THREAD_ID"}
    return {
        key: value
        for key, value in os.environ.items()
        if key not in skip and not (agent == "codex" and key.startswith("PILOT_"))
    }


def _write_failed_marker(run_dir: Path, reason: str, details: str = "") -> None:
    run_dir.mkdir(parents=True, exist_ok=True)
    (run_dir / "failed.json").write_text(
        json.dumps(
            {
                "failed": True,
                "reason": reason,
                "details": details,
                "timestamp": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
            },
            indent=2,
        )
    )


def execute_run(  # noqa: PLR0913
    *,
    prompt: str,
    config_dir: Path,
    run_dir: Path,
    model: str,
    timeout: int,
    skip_permissions: bool = False,
    agent: str = "claude",
) -> ExecuteResult:
    """Run an agent once in config_dir. Saves transcript + timing.json or failed.json."""
    if agent == "codex":
        return _execute_run_codex(
            prompt=prompt,
            config_dir=config_dir,
            run_dir=run_dir,
            model=model,
            timeout=timeout,
            skip_permissions=skip_permissions,
        )
    return _execute_run_claude(
        prompt=prompt,
        config_dir=config_dir,
        run_dir=run_dir,
        model=model,
        timeout=timeout,
        skip_permissions=skip_permissions,
    )


def _execute_run_claude(
    *,
    prompt: str,
    config_dir: Path,
    run_dir: Path,
    model: str,
    timeout: int,
    skip_permissions: bool = False,
) -> ExecuteResult:
    """Run `claude -p` once in config_dir."""
    run_dir.mkdir(parents=True, exist_ok=True)
    outputs = run_dir / "outputs"
    outputs.mkdir(exist_ok=True)

    cmd = [
        "claude",
        "-p",
        "--output-format",
        "stream-json",
        "--model",
        model,
    ]
    if skip_permissions:
        cmd.append("--dangerously-skip-permissions")

    try:
        completed = subprocess.run(
            cmd,
            input=prompt,
            cwd=str(config_dir),
            env=_make_subprocess_env("claude"),
            capture_output=True,
            text=True,
            timeout=timeout,
            check=False,
        )
    except subprocess.TimeoutExpired:
        _write_failed_marker(run_dir, reason="timeout", details=f"after {timeout}s")
        return ExecuteFailure(success=False, reason="timeout")
    except FileNotFoundError:
        _write_failed_marker(run_dir, reason="claude-cli-not-found")
        return ExecuteFailure(success=False, reason="claude-cli-not-found")

    stdout = completed.stdout or ""
    _ = (outputs / "transcript.jsonl").write_text(stdout)
    if completed.stderr:
        _ = (outputs / "stderr.log").write_text(completed.stderr)

    lines = stdout.splitlines()
    result_event = extract_final_result_event(lines)
    if result_event is None:
        _write_failed_marker(
            run_dir,
            reason="no-result-event",
            details=f"exit={completed.returncode}; stdout head: {stdout[:500]}",
        )
        return ExecuteFailure(success=False, reason="no-result-event")

    try:
        parsed = parse_result_event(result_event)
    except ValueError as err:
        _write_failed_marker(run_dir, reason="malformed-result", details=str(err))
        return ExecuteFailure(success=False, reason="malformed-result")

    timing: dict[str, object] = {
        "agent": "claude",
        "duration_ms": parsed["duration_ms"],
        "duration_api_ms": parsed["duration_api_ms"],
        "total_duration_seconds": round(parsed["duration_ms"] / 1000.0, 3),
        "total_tokens": parsed["total_tokens"],
        "input_tokens": parsed["input_tokens"],
        "output_tokens": parsed["output_tokens"],
        "cache_creation_input_tokens": parsed["cache_creation_input_tokens"],
        "cache_read_input_tokens": parsed["cache_read_input_tokens"],
        "total_cost_usd": parsed["total_cost_usd"],
        "session_id": parsed["session_id"],
    }
    _ = (run_dir / "timing.json").write_text(json.dumps(timing, indent=2))
    _ = (outputs / "output.txt").write_text(parsed["result_text"])

    return ExecuteSuccess(
        success=True,
        duration_ms=parsed["duration_ms"],
        total_tokens=parsed["total_tokens"],
        run_dir=str(run_dir),
    )


def _execute_run_codex(
    *,
    prompt: str,
    config_dir: Path,
    run_dir: Path,
    model: str,
    timeout: int,
    skip_permissions: bool = False,
) -> ExecuteResult:
    """Run `codex exec` once in config_dir."""
    run_dir.mkdir(parents=True, exist_ok=True)
    outputs = run_dir / "outputs"
    outputs.mkdir(exist_ok=True)

    import time

    cmd = _codex_exec_command()
    if model and model != CODEX_DEFAULT_MODEL:
        cmd.extend(["--model", model])
    if skip_permissions:
        cmd.extend(["-c", 'approval_policy="never"', "-c", 'sandbox_mode="danger-full-access"'])

    start_ns = time.monotonic_ns()
    try:
        completed = subprocess.run(
            cmd,
            input=prompt,
            cwd=str(config_dir),
            env=_make_subprocess_env("codex"),
            capture_output=True,
            text=True,
            timeout=timeout,
            check=False,
        )
    except subprocess.TimeoutExpired:
        _write_failed_marker(run_dir, reason="timeout", details=f"after {timeout}s")
        return ExecuteFailure(success=False, reason="timeout")
    except FileNotFoundError:
        _write_failed_marker(run_dir, reason="codex-cli-not-found")
        return ExecuteFailure(success=False, reason="codex-cli-not-found")

    elapsed_ms = (time.monotonic_ns() - start_ns) // 1_000_000

    if completed.returncode != 0:
        _write_failed_marker(
            run_dir,
            reason="codex-exec-failed",
            details=f"exit={completed.returncode}; stderr: {(completed.stderr or '')[:300]}",
        )
        return ExecuteFailure(success=False, reason="codex-exec-failed")

    stdout = completed.stdout or ""
    stderr = completed.stderr or ""
    transcript = f"# Codex execution log\n\n{stderr}\n\n# Final output\n\n{stdout}"
    _ = (outputs / "transcript.txt").write_text(transcript)
    if stderr:
        _ = (outputs / "stderr.log").write_text(stderr)
    _ = (outputs / "output.txt").write_text(stdout)

    timing: dict[str, object] = {
        "agent": "codex",
        "duration_ms": elapsed_ms,
        "duration_api_ms": 0,
        "total_duration_seconds": round(elapsed_ms / 1000.0, 3),
        "total_tokens": 0,
        "input_tokens": 0,
        "output_tokens": 0,
        "cache_creation_input_tokens": 0,
        "cache_read_input_tokens": 0,
        "total_cost_usd": 0,
        "session_id": "",
        "note": "token counts not available from codex exec",
    }
    _ = (run_dir / "timing.json").write_text(json.dumps(timing, indent=2))

    return ExecuteSuccess(
        success=True,
        duration_ms=elapsed_ms,
        total_tokens=0,
        run_dir=str(run_dir),
    )


def _run_grader(  # noqa: PLR0913
    run_dir: Path,
    assertions: list[str],
    target_type: str,
    model: str,
    timeout: int,
    skip_permissions: bool = False,
    agent: str = "claude",
) -> GraderResult:
    """Spawn the grader agent. Writes `grading.json` into run_dir."""
    grader_prompt_path = Path(__file__).resolve().parent.parent / "agents" / "grader.md"
    grader_instructions = grader_prompt_path.read_text()

    outputs_dir = run_dir / "outputs"
    transcript_name = "transcript.jsonl" if agent == "claude" else "transcript.txt"
    transcript = outputs_dir / transcript_name
    expectations_block = "\n".join(f"- {a}" for a in assertions)
    prompt = (
        f"{grader_instructions}\n\n"
        f"# Grading task\n\n"
        f"- target_type: {target_type}\n"
        f"- transcript_path: {transcript}\n"
        f"- outputs_dir: {outputs_dir}\n\n"
        f"## Expectations\n\n"
        f"{expectations_block}\n\n"
        f"Write your JSON verdict to: {run_dir / 'grading.json'}"
    )

    if agent == "codex":
        grader_cmd = _codex_exec_command()
        if model and model != CODEX_DEFAULT_MODEL:
            grader_cmd.extend(["--model", model])
        if skip_permissions:
            grader_cmd.extend(["-c", 'approval_policy="never"', "-c", 'sandbox_mode="danger-full-access"'])
    else:
        grader_cmd = ["claude", "-p", "--output-format", "text", "--model", model]
        if skip_permissions:
            grader_cmd.append("--dangerously-skip-permissions")
    try:
        _ = subprocess.run(
            grader_cmd,
            input=prompt,
            env=_make_subprocess_env(agent),
            capture_output=True,
            text=True,
            timeout=timeout,
            check=False,
        )
    except (subprocess.TimeoutExpired, FileNotFoundError) as err:
        _write_failed_marker(run_dir, reason="grader-failed", details=str(err))
        return GraderFailure(graded=False, reason="grader-failed")

    grading_file = run_dir / "grading.json"
    if not grading_file.exists():
        _write_failed_marker(run_dir, reason="grader-no-output")
        return GraderFailure(graded=False, reason="grader-no-output")
    try:
        grading_data: dict[str, object] = json.loads(grading_file.read_text())
        return GraderSuccess(graded=True, grading=grading_data)
    except json.JSONDecodeError as err:
        _write_failed_marker(run_dir, reason="grader-invalid-json", details=str(err))
        return GraderFailure(graded=False, reason="grader-invalid-json")


def _write_eval_metadata(eval_obj: EvalSpec, eval_dir: Path) -> None:
    """Write eval_metadata.json once per eval, before any run starts."""
    eval_id = eval_obj.get("id", 0)
    eval_name = eval_obj.get("name", f"eval-{eval_id}")
    eval_dir.mkdir(parents=True, exist_ok=True)
    (eval_dir / "eval_metadata.json").write_text(
        json.dumps(
            {
                "eval_id": eval_id,
                "eval_name": eval_name,
                "prompt": eval_obj.get("prompt", ""),
                "assertions": eval_obj.get("expectations", eval_obj.get("assertions", [])),
            }
        )
    )


def _run_single_run(
    spec: RunSpec,
    target: TargetConfig,
    output_dir: Path,
    run_cfg: RunConfig,
    reporter: ProgressReporter | None = None,
) -> None:
    """Execute one (eval, config, run_idx) — the unit of pool parallelism."""
    eval_obj = spec.eval_obj
    config_kind = spec.config_kind
    run_idx = spec.run_idx
    eval_id = eval_obj.get("id", 0)
    eval_dir = output_dir / f"eval-{eval_id}"
    eval_prompt = eval_obj.get("prompt", "")
    config_dir_name = "with_skill" if config_kind == "with" else "without_skill"
    run_dir = eval_dir / config_dir_name / f"run-{run_idx}"

    if reporter is not None:
        reporter.on_started(eval_id, config_dir_name, run_idx)

    tmp_root = Path(tempfile.mkdtemp(prefix="pilot-bench-", dir="/tmp"))
    TEMP_DIRS.append(tmp_root)
    try:
        cfg_dir = prepare_config_dir(target, config_kind, tmp_root, agent=run_cfg.agent)
        resolved_prompt = substitute_sandbox(eval_prompt, cfg_dir)
        result = execute_run(
            prompt=resolved_prompt,
            config_dir=cfg_dir,
            run_dir=run_dir,
            model=run_cfg.model,
            timeout=run_cfg.timeout,
            skip_permissions=run_cfg.skip_permissions,
            agent=run_cfg.agent,
        )
        if isinstance(result, ExecuteSuccess):
            _ = _run_grader(
                run_dir=run_dir,
                assertions=eval_obj.get("expectations", eval_obj.get("assertions", [])),
                target_type=target.get("type", "skill"),
                model=run_cfg.grader_model,
                timeout=run_cfg.grader_timeout,
                skip_permissions=run_cfg.skip_permissions,
                agent=run_cfg.grader_agent,
            )
            if reporter is not None:
                reporter.on_completed(
                    eval_id,
                    config_dir_name,
                    run_idx,
                    duration_s=result.duration_ms / 1000.0,
                    tokens=result.total_tokens,
                )
        else:
            if reporter is not None:
                reporter.on_failed(eval_id, config_dir_name, run_idx, result.reason)
    except Exception as exc:
        if reporter is not None:
            reporter.on_failed(eval_id, config_dir_name, run_idx, f"worker-error: {exc}")
        raise
    finally:
        shutil.rmtree(tmp_root, ignore_errors=True)
        if tmp_root in TEMP_DIRS:
            TEMP_DIRS.remove(tmp_root)


def _announce_contamination(target: TargetConfig, isolate_global: bool, agent: str) -> list[Path]:
    """Log contamination status and return the paths that should be hidden.

    Returns an empty list when isolation is disabled (but still warns the user
    about detected-but-not-hidden duplicates so silent contamination is impossible).
    """
    suspects = detect_global_contamination(target, agent=agent)
    if not suspects:
        return []
    if isolate_global:
        print(
            f"  🛡  auto-isolating {len(suspects)} global counterpart(s) of the target "
            "so the `without` config is truly without it:",
            file=sys.stderr,
        )
        for s in suspects:
            print(f"       {s}", file=sys.stderr)
        return suspects
    print(
        f"  ⚠  --no-isolate-global: {len(suspects)} global counterpart(s) of the target "
        "will contaminate the `without` config (use for realistic 'with + without' measurement):",
        file=sys.stderr,
    )
    for s in suspects:
        print(f"       {s}", file=sys.stderr)
    return []


def _warn_prompt_contamination(evals: list[EvalSpec]) -> None:
    for eval_obj in evals:
        warning = validate_prompt_isolation(eval_obj.get("prompt", ""))
        if warning:
            eval_id = eval_obj.get("id", 0)
            eval_name = eval_obj.get("name", f"eval-{eval_id}")
            print(f"  ⚠  eval-{eval_id} ({eval_name}): {warning}", file=sys.stderr)


def _select_evals(evals: list[EvalSpec], selectors: tuple[str, ...]) -> list[EvalSpec]:
    """Select eval IDs or names while preserving their config-file order."""
    requested = {selector.strip() for selector in selectors if selector.strip()}
    if not requested:
        return evals

    matched: set[str] = set()
    selected: list[EvalSpec] = []
    for eval_obj in evals:
        eval_id = str(eval_obj.get("id", 0))
        eval_name = eval_obj.get("name", f"eval-{eval_id}")
        keys = {eval_id, eval_name}
        overlap = requested & keys
        if overlap:
            selected.append(eval_obj)
            matched.update(overlap)

    unknown = sorted(requested - matched)
    if unknown:
        available = ", ".join(
            f"{eval_obj.get('id', 0)}:{eval_obj.get('name', f'eval-{eval_obj.get("id", 0)}')}"
            for eval_obj in evals
        )
        raise ValueError(f"unknown eval selector(s): {', '.join(unknown)}; available: {available}")
    return selected


def _announce_conditional_loading(target: TargetConfig) -> None:
    """Surface which target files will have path/paths frontmatter stripped.

    Stripping happens silently inside prepare_config_dir on each worker; this
    function prints a single up-front summary so the user knows the run is
    measuring rule content, not rule activation.
    """
    findings = detect_conditional_loading(target)
    if not findings:
        return
    print(
        f"  🔓 stripping conditional-loading frontmatter from {len(findings)} file(s) "
        "in the `with` copy so the target loads for every prompt:",
        file=sys.stderr,
    )
    for path, fields in findings:
        print(f"       {path.name}: {', '.join(fields)}", file=sys.stderr)


def run_benchmark(
    config_path: Path,
    output_dir: Path,
    run_cfg: RunConfig,
    configs: list[str],
    workers: int,
    isolate_global: bool = True,
) -> int:
    if not config_path.exists():
        print(f"Config not found: {config_path}", file=sys.stderr)
        return 1

    data: dict[str, object] = json.loads(config_path.read_text())
    target = load_target_config(config_path)
    target_path_str = target.get("path", "")
    if "name" not in target and target_path_str:
        target["name"] = Path(target_path_str).name

    raw_evals = data.get("evals")
    evals: list[EvalSpec] = list(raw_evals) if isinstance(raw_evals, list) else []
    if not evals:
        print("No evals in config.", file=sys.stderr)
        return 1
    try:
        evals = _select_evals(evals, run_cfg.eval_selectors)
    except ValueError as exc:
        print(str(exc), file=sys.stderr)
        return 1

    output_dir.mkdir(parents=True, exist_ok=True)

    _warn_prompt_contamination(evals)
    _announce_conditional_loading(target)
    to_hide = _announce_contamination(target, isolate_global, run_cfg.agent)

    plan = PlanHeader(
        config_path=str(config_path),
        target_type=target.get("type", "skill"),
        target_path=target_path_str,
        output_dir=str(output_dir),
        n_evals=len(evals),
        n_configs=len(configs),
        n_runs=run_cfg.runs,
        workers=workers,
        executor_model=run_cfg.model,
        grader_model=run_cfg.grader_model,
    )
    use_color = sys.stdout.isatty()
    print(render_plan_header(plan, use_color=use_color))

    for eval_obj in evals:
        eval_id = eval_obj.get("id", 0)
        _write_eval_metadata(eval_obj, output_dir / f"eval-{eval_id}")

    total_runs = len(evals) * len(configs) * run_cfg.runs
    reporter = ProgressReporter(total_runs, workers=workers, use_color=use_color)
    specs: list[RunSpec] = []
    for eval_obj in evals:
        eval_id = eval_obj.get("id", 0)
        eval_name = eval_obj.get("name", f"eval-{eval_id}")
        for cfg in configs:
            cfg_dir_name = "with_skill" if cfg == "with" else "without_skill"
            for run_idx in range(1, run_cfg.runs + 1):
                reporter.register(eval_id, eval_name, cfg_dir_name, run_idx)
                specs.append(RunSpec(eval_obj=eval_obj, config_kind=cfg, run_idx=run_idx))

    reporter.start()
    try:
        with isolate_global_contamination(to_hide):
            with ThreadPoolExecutor(max_workers=workers) as pool:
                futures = [pool.submit(_run_single_run, spec, target, output_dir, run_cfg, reporter) for spec in specs]
                for fut in as_completed(futures):
                    try:
                        fut.result()
                    except Exception as exc:
                        print(f"Worker error (run may have partial results): {exc}", file=sys.stderr)
    finally:
        reporter.stop()

    print(reporter.summary())

    try:
        from scripts import aggregate_benchmark as agg
    except ImportError as err:
        print(f"Failed to import aggregate_benchmark: {err}", file=sys.stderr)
        return 1
    benchmark = agg.generate_benchmark(output_dir, skill_name=target.get("name", ""), skill_path=target_path_str)
    benchmark["metadata"]["target_type"] = target.get("type", "skill")
    benchmark["metadata"]["target_name"] = target.get("name", "")
    benchmark["metadata"]["target_path"] = target_path_str
    benchmark["metadata"]["executor_model"] = run_cfg.model
    benchmark["metadata"]["runs_per_configuration"] = run_cfg.runs

    _ = (output_dir / "benchmark.json").write_text(json.dumps(benchmark, indent=2))
    _ = (output_dir / "benchmark.md").write_text(agg.generate_markdown(benchmark))
    print(f"Wrote {output_dir / 'benchmark.json'}")
    return 0


def main() -> None:
    install_signal_handlers()
    recover_stale_manifests()

    parser = argparse.ArgumentParser(description="benchmark runner — run before/after comparison evaluations")
    parser.add_argument("--config", type=Path, help="Path to evals.json")
    parser.add_argument("--output", type=Path, help="Output directory (default: benchmarks/<target>/runs/<ts>/)")
    parser.add_argument(
        "--runs",
        type=int,
        default=1,
        help="Runs per eval × config (default: 1 — bump for variance analysis)",
    )
    parser.add_argument(
        "--model",
        default=None,
        help=(
            "Executor model. Claude default: target skill's frontmatter `model:` if present, "
            f"otherwise {DEFAULT_FALLBACK_MODEL} for rules and for Pilot-shipped skills "
            "(spec-plan, fix, prd, …) which no longer carry frontmatter model. "
            "Codex default: omit --model and use the active Codex model."
        ),
    )
    parser.add_argument(
        "--grader-model",
        default=None,
        help=("Grader model. Default: same as --model so executor and grader stay matched."),
    )
    parser.add_argument(
        "--configs",
        default="with,without",
        help="Comma-separated list of configs: with,without (default: with,without)",
    )
    parser.add_argument(
        "--evals",
        default="",
        help="Comma-separated eval IDs or names to run (default: every eval in the config)",
    )
    parser.add_argument("--timeout", type=int, default=600, help="Per-run timeout seconds (default: 600)")
    parser.add_argument("--grader-timeout", type=int, default=300, help="Grader timeout seconds (default: 300)")
    parser.add_argument("--workers", type=int, default=4, help="Parallel workers (default: 4)")
    parser.add_argument(
        "--skip-permissions",
        action="store_true",
        default=False,
        help="Grant full permissions to all executor and grader subprocess calls. Required for "
        "automated runs (no interactive terminal). Only enable in a trusted, isolated environment.",
    )
    parser.add_argument(
        "--no-isolate-global",
        action="store_true",
        default=False,
        help="Do not hide global counterparts of the target during the run. "
        "Default: auto-hide. Use when you want to measure the target IN ADDITION to "
        "globally-loaded guidance (realistic 'day-to-day' measurement).",
    )
    parser.add_argument(
        "--restore-hidden",
        action="store_true",
        default=False,
        help="Recover any .pilot-bench-hidden-* files left behind by a crashed prior "
        "run and exit. No benchmark is executed.",
    )
    parser.add_argument(
        "--agent",
        default="claude",
        choices=["claude", "codex"],
        help="Agent CLI to use for execution: claude (default) or codex",
    )
    parser.add_argument(
        "--grader-agent",
        default=None,
        choices=["claude", "codex"],
        help="Agent CLI for grading (default: same as --agent)",
    )
    parser.add_argument("--version", action="store_true", help="Print version and exit")
    args = parser.parse_args()

    if args.version:
        print(f"benchmark runner {__version__}")
        sys.exit(0)

    if args.restore_hidden:
        restored = recover_stale_manifests()
        print(f"Restored {restored} hidden path(s).")
        sys.exit(0)

    if args.config is None:
        parser.error("--config is required (unless --version or --restore-hidden)")

    if not args.config.exists():
        print(f"Config not found: {args.config}", file=sys.stderr)
        sys.exit(1)

    configs = [c.strip() for c in args.configs.split(",") if c.strip()]
    if not configs:
        parser.error("--configs must list at least one of: with, without")
    eval_selectors = tuple(selector.strip() for selector in args.evals.split(",") if selector.strip())

    target = load_target_config(args.config)
    output_dir = args.output
    if output_dir is None:
        name = target.get("name") or Path(target.get("path", "target")).name
        ts = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H-%M-%SZ")
        output_dir = Path("benchmarks") / name / "runs" / ts

    agent: str = args.agent
    grader_agent: str = args.grader_agent or agent
    executor_model, grader_model = _resolve_run_models(
        agent=agent,
        grader_agent=grader_agent,
        model_arg=args.model,
        grader_model_arg=args.grader_model,
        target=target,
    )

    run_cfg = RunConfig(
        runs=args.runs,
        model=executor_model,
        grader_model=grader_model,
        timeout=args.timeout,
        grader_timeout=args.grader_timeout,
        skip_permissions=args.skip_permissions,
        agent=agent,
        grader_agent=grader_agent,
        eval_selectors=eval_selectors,
    )
    code = run_benchmark(
        config_path=args.config,
        output_dir=output_dir,
        run_cfg=run_cfg,
        configs=configs,
        workers=args.workers,
        isolate_global=not args.no_isolate_global,
    )
    sys.exit(code)


if __name__ == "__main__":
    main()
