"""Aggregate analytics for cross-run facets, signal extraction, and pattern clustering."""

from typing import TYPE_CHECKING, Any

from autocontext.analytics.campaign_mode_report import CampaignModeReport, build_campaign_mode_report
from autocontext.analytics.context_attribution import (
    ComponentAttribution,
    ContextAttributionLedger,
    attribute_controlled_trials,
    plan_reablation,
    reconstruct_causal_credit,
    select_prompt_components,
)
from autocontext.analytics.exploration_collapse_guard import (
    ExplorationCollapseReport,
    detect_exploration_collapse,
    render_exploration_collapse_report,
)
from autocontext.analytics.goal_run_report import GoalRunReport, build_goal_run_report
from autocontext.analytics.manifest_attribution import (
    attribute_manifest_verified_trials,
    reconstruct_manifest_verified_causal_credit,
)
from autocontext.analytics.negative_result_ledger import NegativeResultLedger, build_negative_result_ledger
from autocontext.analytics.progress_report import RunProgressReport, build_run_progress_report
from autocontext.analytics.run_utilization_report import RunUtilizationReport, build_run_utilization_report
from autocontext.analytics.runtime_session_run_trace import runtime_session_log_to_run_trace
from autocontext.analytics.trace_gate_operator_view import (
    TraceGateAnalysisState,
    TraceGateOperatorState,
    TraceGateOperatorView,
    build_trace_gate_operator_view,
    render_trace_gate_operator_view_lines,
)

if TYPE_CHECKING:
    from autocontext.analytics.false_promotion_calibration import (
        FalsePromotionCalibrationCase,
        FalsePromotionCalibrationResult,
        simulate_false_promotion_campaigns,
    )


def __getattr__(name: str) -> Any:
    """Load calibration exports without creating an analytics/bundle cycle."""

    if name in {
        "FalsePromotionCalibrationCase",
        "FalsePromotionCalibrationResult",
        "simulate_false_promotion_campaigns",
    }:
        from autocontext.analytics.false_promotion_calibration import (
            FalsePromotionCalibrationCase,
            FalsePromotionCalibrationResult,
            simulate_false_promotion_campaigns,
        )

        return {
            "FalsePromotionCalibrationCase": FalsePromotionCalibrationCase,
            "FalsePromotionCalibrationResult": FalsePromotionCalibrationResult,
            "simulate_false_promotion_campaigns": simulate_false_promotion_campaigns,
        }[name]
    raise AttributeError(name)

__all__ = [
    "CampaignModeReport",
    "ComponentAttribution",
    "ContextAttributionLedger",
    "ExplorationCollapseReport",
    "FalsePromotionCalibrationCase",
    "FalsePromotionCalibrationResult",
    "GoalRunReport",
    "NegativeResultLedger",
    "RunProgressReport",
    "RunUtilizationReport",
    "TraceGateAnalysisState",
    "TraceGateOperatorState",
    "TraceGateOperatorView",
    "build_campaign_mode_report",
    "attribute_controlled_trials",
    "attribute_manifest_verified_trials",
    "build_goal_run_report",
    "detect_exploration_collapse",
    "build_negative_result_ledger",
    "build_run_progress_report",
    "build_run_utilization_report",
    "build_trace_gate_operator_view",
    "render_exploration_collapse_report",
    "plan_reablation",
    "reconstruct_causal_credit",
    "reconstruct_manifest_verified_causal_credit",
    "render_trace_gate_operator_view_lines",
    "runtime_session_log_to_run_trace",
    "select_prompt_components",
    "simulate_false_promotion_campaigns",
]
