"""charter models: the ambient daemon's only policy input.

Guardrail floors are enforced here so no charter file can disable them
(spec: docs/internal/ambient-trainer-design.md, "The charter").
"""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

AutonomyLevel = Literal["propose", "train", "full"]
DeploymentTier = Literal["oss", "hosted-box"]
SourceKind = Literal["autocontext", "otel", "proxy", "full-box"]
TrainingMethod = Literal["sft-distill", "rlvr-experimental"]

_FLOOR_MESSAGE = "guardrail floor: this protection cannot be disabled through the charter"


class GuardrailConfig(BaseModel):
    # validate_assignment closes the silent post-construction bypass
    # (attribute assignment re-runs the floor validators). model_construct
    # and model_copy(update=...) still skip validation by pydantic design;
    # never use them on charter models with untrusted input.
    model_config = ConfigDict(validate_assignment=True, extra="forbid")

    frozen_anchor: bool = True
    provenance_quarantine: bool = True
    asymmetric_trainability: bool = True
    drift_canaries: bool = True
    min_frontier_fraction: float = Field(default=0.2, ge=0.05, le=1.0)

    @field_validator("frozen_anchor", "provenance_quarantine", "asymmetric_trainability", "drift_canaries")
    @classmethod
    def _floor(cls, value: bool) -> bool:
        if value is not True:
            raise ValueError(_FLOOR_MESSAGE)
        return value


class CharterAnchor(BaseModel):
    model_config = ConfigDict(extra="forbid")

    provider: str = "anthropic"
    model: str = Field(min_length=1, default="claude-sonnet-5")
    rubric: str = Field(min_length=1, default="Score the response for task success from 0 to 1.")


class CharterSource(BaseModel):
    model_config = ConfigDict(extra="forbid")

    name: str = Field(min_length=1)
    kind: SourceKind
    enabled: bool = True
    # reserved: only "default" is accepted today; alternate redaction
    # profiles are a future slice and rejected by the validator below
    redaction_profile: str = "default"

    @field_validator("redaction_profile")
    @classmethod
    def _reserved_redaction_profile(cls, value: str) -> str:
        if value != "default":
            raise ValueError("redaction profiles beyond default are reserved for a future slice")
        return value


class CharterTarget(BaseModel):
    model_config = ConfigDict(extra="forbid")

    # target names become dataset and manifest filenames under the store root
    # (DatasetStore builds root / f"{name}.jsonl"), so path separators and
    # traversal sequences must be impossible. the pattern forbids a leading dot
    # (so ".." can never start a name) and excludes "/" everywhere; a slug this
    # shape stays inside the store root, so no separate path validator is needed.
    name: str = Field(min_length=1, pattern=r"^[A-Za-z0-9][A-Za-z0-9._-]*$")
    kind: Literal["role", "task_family"]
    selector: str = Field(min_length=1)
    base_model: str = Field(min_length=1)
    method: TrainingMethod = "sft-distill"
    min_dataset_records: int = Field(ge=1)
    eval_suite: str = Field(min_length=1)
    autonomy: AutonomyLevel | None = None


class CharterBudgets(BaseModel):
    model_config = ConfigDict(extra="forbid")

    gpu_hours_per_window: float = Field(gt=0)
    window_hours: int = Field(ge=1)
    disk_quota_gb: float = Field(gt=0)
    priority: Literal["serving", "training"] = "serving"


class AdviseGateConfig(BaseModel):
    """Bounded LLM review gate for advise proposals (AC-900).

    The gate is an evaluative role: frozen under the charter's asymmetric
    trainability posture and never a training target. Absence of this config
    means the gate is off and advise behaves exactly as the LLM-free path.
    """

    model_config = ConfigDict(extra="forbid")

    model: str = Field(min_length=1)
    max_output_tokens: int = Field(default=512, ge=64, le=2048)


class Charter(BaseModel):
    model_config = ConfigDict(extra="forbid")

    tier: DeploymentTier
    control_surface: Literal["local", "autowork"] = "local"
    autonomy: AutonomyLevel = "propose"
    sources: list[CharterSource]
    targets: list[CharterTarget]
    budgets: CharterBudgets
    guardrails: GuardrailConfig = Field(default_factory=GuardrailConfig)
    anchor: CharterAnchor = Field(default_factory=CharterAnchor)
    # When True the evaluate stage scores each candidate's real model generation (which is what makes
    # it promotable); when False it scores the placeholder reference text. This is a policy decision,
    # so it lives in the charter (the only policy input) rather than an env/settings behavior flag.
    real_candidate_generation: bool = False
    # Optional bounded LLM review gate consulted once per advise cycle before
    # proposals are emitted; None keeps today's LLM-free behavior (AC-900).
    advise_gate: AdviseGateConfig | None = None

    @model_validator(mode="after")
    def _full_box_requires_hosted(self) -> Charter:
        for source in self.sources:
            if source.kind == "full-box" and self.tier != "hosted-box":
                raise ValueError("full-box sources require the hosted-box tier")
        return self

    @model_validator(mode="after")
    def _source_names_unique(self) -> Charter:
        # the trace store keys ingest cursors by source name; duplicates
        # would clobber each other's watermarks and silently skip records
        names = [source.name for source in self.sources]
        duplicates = {name for name in names if names.count(name) > 1}
        if duplicates:
            raise ValueError(f"duplicate source names: {sorted(duplicates)}")
        return self

    @model_validator(mode="after")
    def _target_names_unique(self) -> Charter:
        # policy lookups and proposal keying treat target name as a unique key
        names = [target.name for target in self.targets]
        duplicates = {name for name in names if names.count(name) > 1}
        if duplicates:
            raise ValueError(f"duplicate target names: {sorted(duplicates)}")
        return self

    @model_validator(mode="after")
    def _target_names_do_not_collide_with_scenarios(self) -> Charter:
        # ambient candidates are slotted in the model registry by scenario=target.name,
        # so a target named like a real scenario would share the activation slot with the
        # non-ambient records the training runner publishes under that scenario, and
        # registry.activate() could cross-demote them. imported lazily to avoid an import
        # cycle (charter must not pull scenarios at module load); a minimal environment
        # without the registry skips the check rather than hard-failing construction.
        try:
            from autocontext.scenarios import SCENARIO_REGISTRY
        except ImportError:
            return self
        scenario_names = set(SCENARIO_REGISTRY)
        for target in self.targets:
            name = target.name
            if name in scenario_names:
                raise ValueError(
                    f"charter target name {name!r} collides with a registered scenario name; "
                    f"ambient candidates are slotted by target name and would cross-demote "
                    f"non-ambient {name!r} models. Rename the target."
                )
        return self
