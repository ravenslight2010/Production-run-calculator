from __future__ import annotations

import logging
from collections.abc import Callable, Sequence
from contextlib import contextmanager
from dataclasses import dataclass
from threading import RLock
from typing import TYPE_CHECKING, Any

from autocontext.agents import role_runtime_overrides
from autocontext.agents.analyst import AnalystRunner
from autocontext.agents.architect import ArchitectRunner
from autocontext.agents.coach import CoachRunner
from autocontext.agents.competitor import CompetitorRunner
from autocontext.agents.context_evaluation_isolation import isolate_context_bundle_client
from autocontext.agents.context_routing_activation import resolve_active_context_settings
from autocontext.agents.curator import KnowledgeCurator
from autocontext.agents.execution_policy import architect_due, skipped_architect
from autocontext.agents.llm_client import DeferredMLXClient, LanguageModelClient, build_client_from_settings
from autocontext.agents.model_router import ModelRouter, TierConfig
from autocontext.agents.orchestrator_helpers import (
    _assemble_agent_outputs,
    _run_analyst_coach_architect,
    _run_competitor_phase,
    _run_translator_phase,
)
from autocontext.agents.role_router import ProviderClass, RoleRouter, RoutingContext, available_local_models
from autocontext.agents.runtime_session_wiring import runtime_session_client_for_role
from autocontext.agents.skeptic import SkepticAgent
from autocontext.agents.subagent_runtime import SubagentRuntime
from autocontext.agents.translator import StrategyTranslator
from autocontext.agents.trial_summary import build_trial_summary as _build_trial_summary
from autocontext.agents.types import AgentOutputs, RoleExecution
from autocontext.config.provider_model_defaults import resolve_model_default
from autocontext.config.settings import AppSettings
from autocontext.execution.harness_coverage import HarnessCoverage
from autocontext.extensions import HookBus, wrap_language_model_client
from autocontext.harness.orchestration.dag import RoleDAG
from autocontext.harness.orchestration.types import RoleSpec
from autocontext.prompts.templates import PromptBundle, PromptPartsBundle

if TYPE_CHECKING:
    from autocontext.agents.role_router import ProviderConfig

logger = logging.getLogger(__name__)


@dataclass(frozen=True, slots=True)
class _RlmBackendConfig:
    """Resolved RLM worker class and per-role prompt templates."""

    worker_cls: type
    competitor_tpl: str
    analyst_tpl: str
    architect_tpl: str


def _resolve_rlm_backend(settings: AppSettings) -> _RlmBackendConfig:
    """Select worker class and prompt templates based on backend + constraint mode."""
    use_constraints = settings.constraint_prompts_enabled
    if settings.rlm_backend == "monty":
        from autocontext.harness.repl.monty_worker import MontyReplWorker

        if use_constraints:
            from autocontext.rlm.prompts import (
                ANALYST_MONTY_RLM_SYSTEM_CONSTRAINED,
                ARCHITECT_MONTY_RLM_SYSTEM_CONSTRAINED,
                COMPETITOR_MONTY_RLM_SYSTEM_CONSTRAINED,
            )

            return _RlmBackendConfig(
                worker_cls=MontyReplWorker,
                competitor_tpl=COMPETITOR_MONTY_RLM_SYSTEM_CONSTRAINED,
                analyst_tpl=ANALYST_MONTY_RLM_SYSTEM_CONSTRAINED,
                architect_tpl=ARCHITECT_MONTY_RLM_SYSTEM_CONSTRAINED,
            )
        from autocontext.rlm.prompts import (
            ANALYST_MONTY_RLM_SYSTEM,
            ARCHITECT_MONTY_RLM_SYSTEM,
            COMPETITOR_MONTY_RLM_SYSTEM,
        )

        return _RlmBackendConfig(
            worker_cls=MontyReplWorker,
            competitor_tpl=COMPETITOR_MONTY_RLM_SYSTEM,
            analyst_tpl=ANALYST_MONTY_RLM_SYSTEM,
            architect_tpl=ARCHITECT_MONTY_RLM_SYSTEM,
        )
    # Default: exec backend
    from autocontext.rlm.repl_worker import ReplWorker

    if use_constraints:
        from autocontext.rlm.prompts import (
            ANALYST_RLM_SYSTEM_CONSTRAINED,
            ARCHITECT_RLM_SYSTEM_CONSTRAINED,
            COMPETITOR_RLM_SYSTEM_CONSTRAINED,
        )

        return _RlmBackendConfig(
            worker_cls=ReplWorker,
            competitor_tpl=COMPETITOR_RLM_SYSTEM_CONSTRAINED,
            analyst_tpl=ANALYST_RLM_SYSTEM_CONSTRAINED,
            architect_tpl=ARCHITECT_RLM_SYSTEM_CONSTRAINED,
        )
    from autocontext.rlm.prompts import ANALYST_RLM_SYSTEM, ARCHITECT_RLM_SYSTEM, COMPETITOR_RLM_SYSTEM

    return _RlmBackendConfig(
        worker_cls=ReplWorker,
        competitor_tpl=COMPETITOR_RLM_SYSTEM,
        analyst_tpl=ANALYST_RLM_SYSTEM,
        architect_tpl=ARCHITECT_RLM_SYSTEM,
    )


def apply_dag_changes(dag: RoleDAG, changes: Sequence[dict[str, Any]]) -> tuple[int, int]:
    """Apply a list of DAG change directives. Returns (applied, skipped) counts."""
    applied = 0
    skipped = 0
    for change in changes:
        action = change.get("action")
        name = change.get("name", "")
        try:
            if action == "add_role":
                deps = tuple(change.get("depends_on", []))
                dag.add_role(RoleSpec(name=name, depends_on=deps))
                applied += 1
            elif action == "remove_role":
                dag.remove_role(name)
                applied += 1
            else:
                skipped += 1
        except ValueError:
            skipped += 1
    return applied, skipped


class AgentOrchestrator:
    """Runs competitor/analyst/coach/architect role sequence."""

    def __init__(
        self,
        client: LanguageModelClient,
        settings: AppSettings,
        artifacts: Any | None = None,
        sqlite: Any | None = None,
        hook_bus: HookBus | None = None,
    ) -> None:
        self.hook_bus = hook_bus
        self.client = wrap_language_model_client(client, hook_bus)
        self.settings = settings
        self._artifacts = artifacts
        self._harness_coverage_cache: dict[str, HarnessCoverage | None] = {}
        # Keyed by a routing tuple whose shape varies by resolver (role-provider routing uses
        # (provider, model, scenario, role); the mlx/ambient path adds the served model id, AC-893),
        # so the key is a variable-length tuple of optional strings.
        self._routed_clients: dict[tuple[str | None, ...], LanguageModelClient] = {}
        self._disposable_client_ids: set[int] = set()
        self._role_resolution_lock = RLock()

        def runtime() -> SubagentRuntime:
            return SubagentRuntime(client=self.client, constrained_output=settings.constrained_output)

        self.competitor = CompetitorRunner(runtime(), settings.model_competitor, settings.competitor_max_tokens)
        self.translator = StrategyTranslator(runtime(), settings.model_translator, settings.translator_max_tokens)
        self.analyst = AnalystRunner(runtime(), settings.model_analyst, settings.analyst_max_tokens)
        self.coach = CoachRunner(runtime(), settings.model_coach, settings.coach_max_tokens)
        self.architect = ArchitectRunner(runtime(), settings.model_architect, settings.architect_max_tokens)
        self.curator: KnowledgeCurator | None = None
        if settings.curator_enabled:
            self.curator = KnowledgeCurator(
                runtime(),
                settings.model_curator,
                max_tokens=settings.curator_max_tokens,
                rating_max_tokens=settings.curator_rating_max_tokens,
                consolidation_max_tokens=settings.curator_consolidation_max_tokens,
            )
        self.skeptic: SkepticAgent | None = None
        if settings.skeptic_enabled:
            self.skeptic = SkepticAgent(runtime(), settings.model_skeptic, settings.skeptic_max_tokens)
        self._role_clients: dict[str, LanguageModelClient] = {}
        self._active_generation_deadline: float | None = None
        self._context_bundle_evaluation_isolation_depth = 0
        self._role_router = RoleRouter(settings)

        self._model_router = ModelRouter(
            TierConfig(
                enabled=settings.tier_routing_enabled,
                tier_haiku_model=settings.tier_haiku_model,
                tier_sonnet_model=settings.tier_sonnet_model,
                tier_opus_model=settings.tier_opus_model,
                competitor_haiku_max_gen=settings.tier_competitor_haiku_max_gen,
                harness_aware_tiering_enabled=settings.tier_harness_aware_enabled,
                harness_coverage_demotion_threshold=settings.tier_harness_coverage_demotion_threshold,
            )
        )

        self._rlm_loader = None
        if settings.rlm_enabled and settings.agent_provider != "agent_sdk":
            if artifacts is None or sqlite is None:
                raise ValueError("RLM mode requires artifacts and sqlite stores")
            from autocontext.rlm.context_loader import ContextLoader

            self._rlm_loader = ContextLoader(artifacts, sqlite)

    def _wrap_client(self, client: LanguageModelClient, *, provider_name: str = "") -> LanguageModelClient:
        return wrap_language_model_client(client, self.hook_bus, provider_name=provider_name)

    def _mark_disposable_client(self, client: LanguageModelClient) -> LanguageModelClient:
        self._disposable_client_ids.add(id(client))
        return client

    def _close_disposable_client(self, client: LanguageModelClient) -> None:
        if id(client) not in self._disposable_client_ids:
            return
        self._disposable_client_ids.discard(id(client))
        close = getattr(client, "close", None)
        if not callable(close):
            return
        try:
            close()
        except Exception:
            logger.debug("failed to close disposable role runtime client", exc_info=True)

    @classmethod
    def from_settings(
        cls,
        settings: AppSettings,
        artifacts: Any | None = None,
        sqlite: Any | None = None,
        hook_bus: HookBus | None = None,
    ) -> AgentOrchestrator:
        try:
            client: LanguageModelClient = build_client_from_settings(settings)
        except ValueError:
            # mlx agent provider with no explicit path: the model is resolved per-scenario at
            # role execution (the recursive loop). Defer here so the scenario-agnostic
            # orchestrator can be constructed; a genuine no-model misconfig still errors on use.
            if settings.agent_provider == "mlx" and not settings.mlx_model_path:
                client = DeferredMLXClient()
            else:
                raise

        orch = cls(client=client, settings=settings, artifacts=artifacts, sqlite=sqlite, hook_bus=hook_bus)

        role_runtime_overrides.apply_role_overrides(orch, settings)

        return orch

    def apply_active_context_routing(self, settings: AppSettings, routing: dict[str, Any]) -> AppSettings:
        """Synchronize generation-time routes from the immutable active bundle."""
        effective_settings = resolve_active_context_settings(settings, self.settings, routing)
        # An empty routing map is meaningful: the current active bundle no
        # longer overrides generation-time routes. Always resynchronize from
        # the generation's baseline settings so an older promoted bundle cannot
        # leak its models or routing flags into later generations.
        self.settings = effective_settings
        self.competitor.model = effective_settings.model_competitor
        self.analyst.model = effective_settings.model_analyst
        self.coach.model = effective_settings.model_coach
        self.architect.model = effective_settings.model_architect
        self._role_router = RoleRouter(effective_settings)
        self._harness_coverage_cache.clear()
        return effective_settings

    def _client_for_role(self, role: str) -> LanguageModelClient:
        return self._role_clients.get(role, self.client)

    def _configured_role_provider(self, role: str) -> str:
        from autocontext.agents.provider_bridge import configured_role_provider

        return configured_role_provider(role, self.settings)

    def _available_local_models(self, scenario_name: str = "", runtime_type: str = "provider") -> list[str]:
        return available_local_models(
            self.settings,
            scenario_name=scenario_name,
            runtime_type=runtime_type,
        )

    def _scenario_bound_runtime_client(
        self,
        provider_type: str,
        role: str,
        *,
        scenario_name: str,
    ) -> LanguageModelClient | None:
        from autocontext.agents.scenario_bound_clients import scenario_bound_runtime_client

        return scenario_bound_runtime_client(self, provider_type, role, scenario_name=scenario_name)

    def _scenario_bound_override_client(
        self,
        role: str,
        *,
        scenario_name: str,
    ) -> LanguageModelClient | None:
        explicit_provider = self._configured_role_provider(role)
        return self._scenario_bound_runtime_client(
            explicit_provider,
            role,
            scenario_name=scenario_name,
        )

    def _scenario_bound_default_client(
        self,
        role: str,
        *,
        scenario_name: str,
    ) -> LanguageModelClient | None:
        return self._scenario_bound_runtime_client(
            self.settings.agent_provider.lower().strip(),
            role,
            scenario_name=scenario_name,
        )

    def _resolve_role_provider_config(
        self,
        role: str,
        *,
        generation: int,
        retry_count: int = 0,
        is_plateau: bool = False,
        scenario_name: str = "",
    ) -> ProviderConfig | None:
        if self.settings.role_routing != "auto":
            return None
        context = RoutingContext(
            generation=generation,
            retry_count=retry_count,
            is_plateau=is_plateau,
            available_local_models=self._available_local_models(
                scenario_name=scenario_name,
                runtime_type="provider",
            ),
            scenario_name=scenario_name,
        )
        return self._role_router.route(role, context=context)

    def _client_for_provider_config(
        self,
        role: str,
        config: ProviderConfig,
        *,
        scenario_name: str = "",
    ) -> LanguageModelClient:
        default_provider = self.settings.agent_provider.lower()
        default_scenario_client = self._scenario_bound_default_client(role, scenario_name=scenario_name)
        openai_like_default = default_provider in ("openai", "openai-compatible", "ollama", "vllm")
        if (
            config.provider_type == self.settings.agent_provider
            and config.provider_class != ProviderClass.LOCAL
            and not self._configured_role_provider(role)
            and (not openai_like_default or config.model in (None, "", self.settings.agent_default_model))
        ):
            return default_scenario_client or self._client_for_role(role)

        explicit_provider = self._configured_role_provider(role)
        if explicit_provider and explicit_provider == config.provider_type.lower():
            explicit_client = self._role_clients.get(role)
            if explicit_provider in {"pi", "pi-rpc"}:
                scenario_client = self._scenario_bound_override_client(role, scenario_name=scenario_name)
                if scenario_client is not None:
                    return scenario_client
            if explicit_client is not None and (
                config.provider_class != ProviderClass.LOCAL or config.model == self.settings.mlx_model_path
            ):
                return explicit_client

        if (
            config.provider_type == self.settings.agent_provider
            and config.provider_class == ProviderClass.LOCAL
            and config.model == self.settings.mlx_model_path
            and not explicit_provider
        ):
            return default_scenario_client or self._client_for_role(role)

        from autocontext.agents.provider_bridge import create_role_client

        call_settings, is_budgeted = role_runtime_overrides.settings_for_budgeted_role_call(
            self.settings,
            config.provider_type,
            role,
            self._active_generation_deadline,
        )
        key = (config.provider_type.lower(), config.model, scenario_name or None, role)
        if not is_budgeted:
            cached = self._routed_clients.get(key)
            if cached is not None:
                return cached
        client = create_role_client(
            config.provider_type,
            call_settings,
            model_override=config.model,
            scenario_name=scenario_name,
            role=role,
        )
        if client is None:
            return self._client_for_role(role)
        client = self._wrap_client(client, provider_name=f"{config.provider_type}:{role}")
        if is_budgeted:
            self._mark_disposable_client(client)
        else:
            self._routed_clients[key] = client
        return client

    def _resolve_role_execution(
        self,
        role: str,
        *,
        generation: int,
        retry_count: int = 0,
        is_plateau: bool = False,
        scenario_name: str = "",
    ) -> tuple[LanguageModelClient, str | None]:
        client = (
            self._scenario_bound_override_client(role, scenario_name=scenario_name)
            or self._scenario_bound_default_client(role, scenario_name=scenario_name)
            or self._client_for_role(role)
        )
        provider_config = self._resolve_role_provider_config(
            role,
            generation=generation,
            retry_count=retry_count,
            is_plateau=is_plateau,
            scenario_name=scenario_name,
        )
        effective_config = provider_config or self._role_router.route(role)
        model = self.resolve_model(
            role,
            generation=generation,
            retry_count=retry_count,
            is_plateau=is_plateau,
            scenario_name=scenario_name,
            provider=effective_config.provider_type,
            provider_capability=effective_config.provider_class,
        )
        if provider_config is None:
            # Routing-off still needs provider-aware model resolution because
            # runners are constructed from raw Claude defaults.
            if self._role_router.role_model_is_explicit(role):
                return client, self._role_router.resolved_role_model(role, effective_config.provider_type)
            return client, model or effective_config.model
        effective_config, effective_model = role_runtime_overrides.resolve_routed_provider_config(
            self._role_router, role, provider_config, model
        )
        client = self._client_for_provider_config(role, effective_config, scenario_name=scenario_name)
        return client, effective_model

    def resolve_role_execution(
        self,
        role: str,
        *,
        generation: int,
        retry_count: int = 0,
        is_plateau: bool = False,
        scenario_name: str = "",
        generation_deadline: float | None = None,
    ) -> tuple[LanguageModelClient, str | None]:
        """Resolve the effective client and model for a role execution.

        This is the stable public wrapper for non-runner pipeline stages that need
        to respect per-role overrides and automatic routing decisions.
        """
        previous_deadline = self._active_generation_deadline
        self._active_generation_deadline = generation_deadline
        try:
            return self._resolve_role_execution(
                role,
                generation=generation,
                retry_count=retry_count,
                is_plateau=is_plateau,
                scenario_name=scenario_name,
            )
        finally:
            self._active_generation_deadline = previous_deadline

    @contextmanager
    def isolate_context_bundle_evaluation_arm(self) -> Any:
        """Require every role turn in this scope to start without prior-arm state."""
        self._context_bundle_evaluation_isolation_depth += 1
        try:
            yield
        finally:
            self._context_bundle_evaluation_isolation_depth -= 1

    @contextmanager
    def _use_role_runtime(
        self,
        role: str,
        runner: Any,
        *,
        generation: int,
        retry_count: int = 0,
        is_plateau: bool = False,
        scenario_name: str = "",
        generation_deadline: float | None = None,
    ) -> Any:
        original_client = runner.runtime.client
        original_model = runner.model
        with self._role_resolution_lock:
            previous_deadline = self._active_generation_deadline
            self._active_generation_deadline = generation_deadline
            resolved_client: LanguageModelClient | None = None
            try:
                resolved_client, model = self._resolve_role_execution(
                    role,
                    generation=generation,
                    retry_count=retry_count,
                    is_plateau=is_plateau,
                    scenario_name=scenario_name,
                )
            finally:
                self._active_generation_deadline = previous_deadline
        from autocontext.agents.panel_runtime import panel_client_for_role

        def wrap_panel_client(wrapped: LanguageModelClient, provider_name: str) -> LanguageModelClient:
            hooked = self._wrap_client(wrapped, provider_name=provider_name)
            return runtime_session_client_for_role(self, hooked, role)

        client = runtime_session_client_for_role(self, resolved_client, role)
        client = panel_client_for_role(
            self.settings,
            role,
            client,
            scenario_name=scenario_name,
            generation_deadline=generation_deadline,
            wrap_client=wrap_panel_client,
        )
        if self._context_bundle_evaluation_isolation_depth:
            isolate_context_bundle_client(client, role=role)
        runner.runtime.client = client
        if model is not None:
            runner.model = model
        try:
            yield model
        finally:
            runner.runtime.client = original_client
            runner.model = original_model
            if resolved_client is not None:
                self._close_disposable_client(resolved_client)

    def run_generation(
        self,
        prompts: PromptBundle,
        generation_index: int,
        tool_context: str = "",
        run_id: str = "",
        scenario_name: str = "",
        strategy_interface: str = "",
        on_role_event: Callable[[str, str], None] | None = None,
        scenario_rules: str = "",
        current_strategy: dict[str, Any] | None = None,
        generation_deadline: float | None = None,
        parts: PromptPartsBundle | None = None,
    ) -> AgentOutputs:
        # Feature-gated pipeline codepath (skips RLM path when active)
        if self.settings.use_pipeline_engine and not (self.settings.rlm_enabled and self._rlm_loader is not None):
            return self._run_via_pipeline(
                prompts,
                generation_index,
                scenario_name,
                tool_context,
                strategy_interface,
                on_role_event,
                generation_deadline,
                parts=parts,
            )

        def _notify(role: str, status: str) -> None:
            if on_role_event:
                on_role_event(role, status)

        raw_text, competitor_exec = _run_competitor_phase(
            self,
            prompts,
            generation_index,
            tool_context,
            run_id,
            scenario_name,
            strategy_interface,
            scenario_rules,
            current_strategy,
            generation_deadline,
            _notify,
            parts=parts,
        )

        strategy, translator_exec = _run_translator_phase(
            self,
            raw_text,
            strategy_interface,
            generation_index,
            scenario_name,
            generation_deadline,
            _notify,
        )

        architect_prompt = prompts.architect

        analyst_exec, coach_exec, architect_exec = _run_analyst_coach_architect(
            self,
            prompts,
            run_id,
            scenario_name,
            generation_index,
            strategy,
            architect_prompt,
            scenario_rules,
            generation_deadline,
            _notify,
            parts=parts,
        )

        return _assemble_agent_outputs(
            self,
            raw_text,
            strategy,
            competitor_exec,
            translator_exec,
            analyst_exec,
            coach_exec,
            architect_exec,
        )

    def _run_via_pipeline(
        self,
        prompts: PromptBundle,
        generation_index: int,
        scenario_name: str,
        tool_context: str,
        strategy_interface: str,
        on_role_event: Callable[[str, str], None] | None,
        generation_deadline: float | None = None,
        parts: PromptPartsBundle | None = None,
    ) -> AgentOutputs:
        """Execute the 5-role generation via PipelineEngine."""
        from autocontext.agents.pipeline_adapter import build_mts_dag, build_role_handler
        from autocontext.harness.orchestration.engine import PipelineEngine

        dag = build_mts_dag()

        architect_prompt = prompts.architect

        prompt_map = {
            "competitor": prompts.competitor,
            "translator": "",  # translator uses competitor output, not a prompt
            "analyst": prompts.analyst,
            "architect": architect_prompt,
            "coach": prompts.coach,
        }

        # ERP-67 Stage 2b: when structural isolation is on, offer the untrusted
        # reference as a user turn and the trusted instructions as a system turn
        # for the cleanly-mappable roles (competitor/analyst/architect). The
        # handler applies the split only for role-capable clients and otherwise
        # falls back to `flat_map` (byte-identical legacy). Only isolation_safe
        # roles are offered; coach (mid-flight enriched) and translator stay
        # flat. Off / no parts → maps unchanged, legacy behaviour.
        system_map: dict[str, str] = {}
        flat_map: dict[str, str] = {}
        if self.settings.structural_role_isolation and parts is not None:
            role_parts = {
                "competitor": parts.competitor,
                "analyst": parts.analyst,
                "architect": parts.architect,
                "coach": parts.coach,
            }
            for role, rp in role_parts.items():
                if not rp.isolation_safe:
                    continue
                system_map[role] = rp.system
                flat_map[role] = rp.flat
                prompt_map[role] = rp.untrusted_reference

        handler = build_role_handler(
            self,
            generation=generation_index,
            scenario_name=scenario_name,
            tool_context=tool_context,
            strategy_interface=strategy_interface,
            generation_deadline=generation_deadline,
            system_map=system_map,
            flat_map=flat_map,
        )
        engine = PipelineEngine(dag, handler, max_workers=2)
        results = engine.execute(prompt_map, on_role_event=on_role_event)

        # Extract strategy from translator result. This is the strategy being
        # evaluated -- the artifact the whole generation loop scores -- so a
        # parse failure must raise, not silently become an empty dict that
        # then gets executed and scored as a legitimate result. extract_json's
        # default on_failure="raise" matches the direct (non-pipeline) path's
        # StrategyTranslator.translate, which already raises on the same
        # failure; this used to diverge and fail soft instead. It also type-
        # checks, which the old `json.loads(...)` here did not: a translator
        # response shaped as a JSON array (not an object) used to be assigned
        # to `strategy` as-is -- a list silently violating the
        # `dict[str, Any]` every downstream consumer (AgentOutputs,
        # CompetitorOutput) declares and expects.
        #
        # Be clear about what this line can and cannot catch as currently
        # wired, though, because an earlier version of this comment read as
        # if both changes were live here and neither is. pipeline_adapter's
        # translator branch calls `orch.translator.translate(...)`, DISCARDS
        # the strategy it returns, and hands back only the RoleExecution --
        # whose `.content` is either `json.dumps(...)` (always valid) or the
        # very string `translate` just parsed successfully. extract_json is
        # deterministic, so this second parse cannot disagree with the first:
        # any input bad enough to fail here fails inside `translate` one frame
        # earlier and never reaches this line. Through that path neither
        # fail-hard nor the array rejection can actually fire.
        #
        # So this is defense-in-depth, kept deliberately rather than deleted.
        # The adapter's discard-and-re-parse is an implementation detail, not
        # a contract: an adapter that sourced the translator RoleExecution
        # from anywhere other than `translate`'s own return (a cached
        # execution, a retry, a streaming/partial-result path) would put
        # un-vetted content in front of this line, and `use_pipeline_engine`
        # flipping default-on is when that stops being hypothetical. Both
        # behaviors ARE pinned, by tests that stub the role handler to reach
        # this parse for real -- see, in tests/test_pipeline_adapter.py,
        # test_orchestrator_parses_translator_content_and_raises_on_malformed
        # and test_orchestrator_rejects_array_shaped_translator_content.
        from autocontext.harness.core.output_parser import extract_json

        strategy = extract_json(results["translator"].content)
        # Type narrowing for mypy ONLY, not a runtime guard: extract_json is
        # declared `-> dict[str, Any] | None` because of the on_failure="none"
        # variant, but on the default "raise" path it either returns a dict or
        # raises, so the None arm is unreachable here. Asserts are stripped
        # under `python -O`; nothing below depends on this one executing.
        assert strategy is not None

        return _assemble_agent_outputs(
            self,
            results["competitor"].content,
            strategy,
            results["competitor"],
            results["translator"],
            results["analyst"],
            results["coach"],
            results["architect"],
        )

    def resolve_model(
        self,
        role: str,
        *,
        generation: int,
        retry_count: int = 0,
        is_plateau: bool = False,
        scenario_name: str = "",
        harness_coverage: HarnessCoverage | None = None,
        provider: str | None = None,
        provider_capability: ProviderClass | None = None,
    ) -> str | None:
        """Return the model to use for a role, or None to use the default."""
        if harness_coverage is None and role == "competitor":
            harness_coverage = self._get_harness_coverage(scenario_name)
        tier = self._model_router.select_tier(
            role,
            generation=generation,
            retry_count=retry_count,
            is_plateau=is_plateau,
            harness_coverage=harness_coverage,
            max_capability=provider_capability.value if provider_capability is not None else None,
        )
        if tier is None:
            return None
        field_name = f"tier_{tier}_model"
        configured: str = getattr(self.settings, field_name)
        provider_class = {"haiku": "fast", "sonnet": "mid_tier", "opus": "frontier"}.get(tier)
        return (
            resolve_model_default(
                self.settings,
                provider=provider or self.settings.agent_provider,
                field_name=field_name,
                configured=configured,
                provider_class=provider_class,
            )
            or configured
        )

    def _get_harness_coverage(self, scenario_name: str) -> HarnessCoverage | None:
        """Load and cache harness coverage for a scenario when routing needs it."""
        if not self.settings.tier_harness_aware_enabled or not scenario_name or self._artifacts is None:
            return None
        if scenario_name in self._harness_coverage_cache:
            return self._harness_coverage_cache[scenario_name]

        from autocontext.execution.harness_coverage import HarnessCoverageAnalyzer
        from autocontext.execution.harness_loader import HarnessLoader

        harness_dir = self._artifacts.harness_dir(scenario_name)
        loader = HarnessLoader(harness_dir, timeout_seconds=self.settings.harness_timeout_seconds)
        loader.load()
        if not loader.loaded_names:
            self._harness_coverage_cache[scenario_name] = None
            return None

        # Until we persist historical harness accuracy, treat loaded scenario
        # harnesses as trusted executable constraints for routing purposes.
        coverage = HarnessCoverageAnalyzer().analyze(loader, validation_accuracy=1.0)
        self._harness_coverage_cache[scenario_name] = coverage
        return coverage

    def _enrich_coach_prompt(self, base_prompt: str, analyst_content: str) -> str:
        return base_prompt + f"\n\n--- Analyst findings (this generation) ---\n{analyst_content}\n"

    def _run_single_rlm_session(
        self,
        role: str,
        model: str,
        system_tpl: str,
        context: Any,
        worker_cls: type,
        *,
        client: LanguageModelClient | None = None,
    ) -> tuple[RoleExecution, list[Any]]:
        """Build and run a single RLM REPL session for the given role.

        Returns (role_execution, execution_history) where execution_history
        is a list of ExecutionRecord from the session.
        """
        from autocontext.rlm.session import RlmSession, make_llm_batch

        settings = self.settings
        ns = dict(context.variables)
        role_client = client or self._client_for_role(role)
        ns["llm_batch"] = make_llm_batch(role_client, settings.rlm_sub_model)
        worker = worker_cls(
            namespace=ns,
            max_stdout_chars=settings.rlm_max_stdout_chars,
            timeout_seconds=settings.rlm_code_timeout_seconds,
        )
        system_prompt = system_tpl.format(
            max_stdout_chars=settings.rlm_max_stdout_chars,
            max_turns=settings.rlm_max_turns,
            variable_summary=context.summary,
        )
        session = RlmSession(
            client=role_client,
            worker=worker,
            role=role,
            model=model,
            system_prompt=system_prompt,
            max_turns=settings.rlm_max_turns,
        )
        role_exec = session.run()
        return role_exec, session.execution_history

    def _run_rlm_competitor(
        self,
        run_id: str,
        scenario_name: str,
        generation_index: int,
        *,
        model: str | None = None,
        strategy_interface: str = "",
        scenario_rules: str = "",
        current_strategy: dict[str, Any] | None = None,
    ) -> tuple[str, RoleExecution]:
        """Run the Competitor via an RLM REPL session.

        Returns (raw_text, competitor_exec) matching the CompetitorRunner.run() contract.
        The raw_text is the answer content (expected to be a JSON strategy string).
        """
        if self._rlm_loader is None:
            raise RuntimeError("RLM loader not initialized")

        backend = _resolve_rlm_backend(self.settings)

        # Reset deterministic client turn counter if applicable
        competitor_client, resolved_model = self._resolve_role_execution(
            "competitor",
            generation=generation_index,
            scenario_name=scenario_name,
        )
        reset_turns = getattr(competitor_client, "reset_rlm_turns", None)
        if callable(reset_turns):
            reset_turns()

        competitor_ctx = self._rlm_loader.load_for_competitor(
            run_id,
            scenario_name,
            generation_index,
            strategy_interface=strategy_interface,
            scenario_rules=scenario_rules,
            current_strategy=current_strategy,
        )
        resolved_model = model or resolved_model or self.settings.model_competitor
        competitor_exec, exec_history = self._run_single_rlm_session(
            role="competitor",
            model=resolved_model,
            system_tpl=backend.competitor_tpl,
            context=competitor_ctx,
            worker_cls=backend.worker_cls,
            client=competitor_client,
        )

        # Store RLM trial summary for experiment log
        if exec_history:
            summary = _build_trial_summary(generation_index, exec_history, competitor_exec)
            try:
                self._rlm_loader.sqlite.append_agent_output(
                    run_id,
                    generation_index,
                    "competitor_rlm_trials",
                    summary,
                )
            except Exception:
                logger.debug("failed to store RLM trial summary", exc_info=True)

        raw_text = competitor_exec.content
        return raw_text, competitor_exec

    def _run_rlm_roles(
        self,
        run_id: str,
        scenario_name: str,
        generation_index: int,
        strategy: dict[str, Any],
        architect_prompt: str,
        *,
        scenario_rules: str = "",
    ) -> tuple[RoleExecution, RoleExecution]:
        """Run Analyst and Architect via RLM sessions."""
        if self._rlm_loader is None:
            raise RuntimeError("RLM loader not initialized")

        backend = _resolve_rlm_backend(self.settings)

        # Reset deterministic client turn counter if applicable
        analyst_client, analyst_model = self._resolve_role_execution(
            "analyst",
            generation=generation_index,
            scenario_name=scenario_name,
        )
        reset_turns = getattr(analyst_client, "reset_rlm_turns", None)
        if callable(reset_turns):
            reset_turns()

        # --- Analyst ---
        analyst_ctx = self._rlm_loader.load_for_analyst(
            run_id,
            scenario_name,
            generation_index,
            scenario_rules=scenario_rules,
            current_strategy=strategy,
        )
        analyst_exec, _ = self._run_single_rlm_session(
            role="analyst",
            model=analyst_model or self.settings.model_analyst,
            system_tpl=backend.analyst_tpl,
            context=analyst_ctx,
            worker_cls=backend.worker_cls,
            client=analyst_client,
        )

        if not architect_due(generation_index, self.settings.architect_every_n_gens):
            return analyst_exec, skipped_architect(generation_index, self.settings.architect_every_n_gens)

        # Reset turn counter between roles for deterministic client
        architect_client, architect_model = self._resolve_role_execution(
            "architect",
            generation=generation_index,
            scenario_name=scenario_name,
        )
        reset_turns = getattr(architect_client, "reset_rlm_turns", None)
        if callable(reset_turns):
            reset_turns()

        # --- Architect ---
        architect_ctx = self._rlm_loader.load_for_architect(
            run_id,
            scenario_name,
            generation_index,
            scenario_rules=scenario_rules,
        )
        architect_exec, _ = self._run_single_rlm_session(
            role="architect",
            model=architect_model or self.settings.model_architect,
            system_tpl=backend.architect_tpl,
            context=architect_ctx,
            worker_cls=backend.worker_cls,
            client=architect_client,
        )

        return analyst_exec, architect_exec
