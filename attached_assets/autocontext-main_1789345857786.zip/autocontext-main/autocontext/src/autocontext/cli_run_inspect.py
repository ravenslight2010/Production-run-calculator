"""AC-697 slice 7: `autoctx show` + `autoctx watch` commands.

Extracted from ``cli.py`` (PR #1002 review P1) so the parent module
stays under the 1600-line guard. Both commands compose the existing
``store.get_run`` and ``store.run_status`` read surfaces.

``show <run-id> [--best] [--generation N] [--json]``
    Renders a finished run's metadata + selected generations. ``--best``
    filters to the single top-scoring generation; ``--generation N``
    filters to a specific index.

``watch <run-id> [--interval N] [--json]``
    Polls run status on an interval and emits one transition-aware
    line / JSONL row per change. Exits when the run row reaches a
    terminal status, including runs that fail before recording a
    generation.
"""

from __future__ import annotations

import importlib
import json
import sys
import time
from typing import TYPE_CHECKING, Any

import typer
from rich.table import Table

from autocontext.cli_wire import run_show_wire_payload, run_status_wire_payload
from autocontext.execution.epoch_lineage import annotate_status_rows, revision_fields
from autocontext.execution.evaluator_epoch_registry import EvaluatorEpochRegistry

if TYPE_CHECKING:
    from rich.console import Console

    from autocontext.config.settings import AppSettings
    from autocontext.storage.sqlite_store import SQLiteStore

_TERMINAL_STATUSES = frozenset({"completed", "failed", "succeeded", "errored", "stopped"})


def _watch_run_until_terminal(
    store: Any,
    *,
    run_id: str,
    interval: float,
    stream_output: bool,
    console: Any,
) -> None:
    last_emit: tuple[int, str] | None = None
    while True:
        run = store.get_run(run_id)
        run_status = str((run or {}).get("status", "")).lower()
        rows = store.run_status(run_id)
        latest = rows[-1] if rows else None
        if latest is not None:
            current = (int(latest["generation_index"]), str(latest["status"]))
            if current != last_emit:
                if stream_output:
                    sys.stdout.write(json.dumps(run_status_wire_payload(run or {}, rows, run_id=run_id)) + "\n")
                    sys.stdout.flush()
                else:
                    console.print(
                        f"gen={latest['generation_index']} status={latest['status']} "
                        f"best={latest['best_score']:.4f} gate={latest['gate_decision']}"
                    )
                last_emit = current
            # A generation can be complete while the parent run is still
            # producing later generations. The run row owns the lifecycle.
            if run_status in _TERMINAL_STATUSES:
                return
        elif run_status in _TERMINAL_STATUSES:
            if stream_output:
                sys.stdout.write(json.dumps(run_status_wire_payload(run or {}, rows, run_id=run_id)) + "\n")
                sys.stdout.flush()
            else:
                console.print(f"run status={run_status} (no generations recorded)")
            return
        time.sleep(interval)

# AC-885 Slice D1: map the four-state lineage classification to a compact rich "Lineage" cell.
_LINEAGE_LABELS = {"current": "ok", "stale": "stale", "unknown": "legacy", "no_active_epoch": "-"}


def annotate_run_status_rows(
    settings: AppSettings,
    scenario: str | None,
    rows: list[dict[str, Any]],
    store: SQLiteStore,
    run_id: str,
) -> tuple[list[dict[str, Any]], str | None]:
    """Annotate run_status rows with epoch lineage (AC-885 Slice D1) + recorded re-scores (Slice D2c).

    Shared by ``show`` and ``status`` so the registry root is constructed in one place. Builds the
    per-scenario epoch registry under ``settings.knowledge_root / "_evaluator_epochs"`` (same root as
    ``cli_epoch``) and delegates to ``annotate_status_rows``. Then merges the latest active-epoch re-score
    per generation (recorded by ``rescore --apply``) onto each row via ``revision_fields``. Read-only.

    ``store.latest_active_revisions`` returns ``{}`` when ``active_epoch_id`` is None, so every row still
    gains the null-revision fields, keeping the surfaced shape consistent. Inputs are not mutated.
    """
    registry = EvaluatorEpochRegistry(settings.knowledge_root / "_evaluator_epochs")
    rows, active_epoch_id = annotate_status_rows(rows, scenario, registry)
    revs = store.latest_active_revisions(run_id, active_epoch_id)
    for row in rows:
        row.update(revision_fields(revs.get(row["generation_index"])))
    return rows, active_epoch_id


def _lineage_cell(row: dict[str, Any]) -> str:
    """Render the ``Lineage`` column value, marking quarantined rows."""
    label = _LINEAGE_LABELS.get(row.get("evaluator_epoch_status", ""), "-")
    if row.get("quarantined"):
        label = f"{label}+quarantined"
    return label


def _revised_cell(row: dict[str, Any]) -> str:
    """Render the compact ``Revised`` column value: the latest active-epoch re-score, or ``-`` (AC-885 D2c)."""
    revised = row.get("revised_score")
    return f"{revised:.4f}" if revised is not None else "-"


def _revised_note_line(rows: list[dict[str, Any]]) -> str | None:
    """Return a single note line if any row carries an active-epoch re-score, else None (AC-885 D2c)."""
    revised = [r for r in rows if r.get("has_active_revision")]
    if not revised:
        return None
    return (
        f"[cyan]{len(revised)} generation(s) have an active-epoch re-score recorded via `rescore --apply`; "
        "the live score of record is unchanged.[/cyan]"
    )


def _stale_warning_line(rows: list[dict[str, Any]], active_epoch_id: str | None) -> str | None:
    """Return a single warning line if any row is stale or quarantined, else None.

    Stale and quarantined are distinct states and are reported separately: a stale row's epoch differs
    from the active epoch, while a quarantined row was scored under an unpromoted epoch. A row can be
    ``current`` yet quarantined (a promotion activated the epoch before quarantine cleanup ran), or
    quarantined with no active epoch, so quarantine must not be folded into the "stale" wording.
    """
    stale = [r for r in rows if r.get("evaluator_epoch_status") == "stale"]
    quarantined = [r for r in rows if r.get("quarantined")]
    if not stale and not quarantined:
        return None
    active8 = active_epoch_id[:8] if active_epoch_id else "none"
    parts: list[str] = []
    if stale:
        parts.append(f"{len(stale)} generation(s) scored under a stale evaluator epoch")
    if quarantined:
        parts.append(f"{len(quarantined)} generation(s) quarantined (scored under an unpromoted epoch)")
    return f"[yellow]Warning: {'; '.join(parts)}; active epoch {active8}...[/yellow]"


def _cli_attr(dependency_module: str, name: str) -> Any:
    return getattr(importlib.import_module(dependency_module), name)


def register_run_inspect_commands(
    app: typer.Typer,
    *,
    console: Console,
    dependency_module: str = "autocontext.cli",
) -> None:
    """Mount `show` and `watch` on ``app``.

    Both commands resolve `load_settings` / `_sqlite_from_settings` /
    `_write_json_stdout` / `_write_json_stderr` from the
    ``dependency_module`` so tests can substitute store stubs by
    monkey-patching the parent module.
    """

    @app.command()
    def show(
        run_id: str | None = typer.Argument(None, metavar="RUN_ID", help="Run id to inspect."),
        run_id_option: str | None = typer.Option(
            None,
            "--run-id",
            help="Named alternative to the run-id positional.",
        ),
        best: bool = typer.Option(False, "--best", help="Show only the best-scoring generation"),
        generation: int | None = typer.Option(None, "--generation", min=1, help="Show a specific generation by index"),
        json_output: bool = typer.Option(False, "--json", help="Output structured JSON"),
    ) -> None:
        """Render a finished run's artifacts (run metadata + selected generations)."""
        load_settings = _cli_attr(dependency_module, "load_settings")
        sqlite_from_settings = _cli_attr(dependency_module, "_sqlite_from_settings")
        write_json_stdout = _cli_attr(dependency_module, "_write_json_stdout")
        write_json_stderr = _cli_attr(dependency_module, "_write_json_stderr")

        resolved_run_id = (run_id_option or run_id or "").strip()
        if not resolved_run_id:
            message = "`autoctx show` requires <run-id>."
            if json_output:
                write_json_stderr(message)
            else:
                console.print(f"[red]Error: {message}[/red]")
            raise typer.Exit(code=2)

        if best and generation is not None:
            message = "--best cannot be combined with --generation"
            if json_output:
                write_json_stderr(message)
            else:
                console.print(f"[red]Error: {message}[/red]")
            raise typer.Exit(code=2)

        settings = load_settings()
        store = sqlite_from_settings(settings)
        run = store.get_run(resolved_run_id)
        if run is None:
            message = f"run {resolved_run_id!r} not found"
            if json_output:
                write_json_stderr(message)
            else:
                console.print(f"[red]{message}[/red]")
            raise typer.Exit(code=1)

        rows = store.run_status(resolved_run_id)
        if best and rows:
            rows = [max(rows, key=lambda r: r["best_score"])]
        elif generation is not None:
            rows = [r for r in rows if r["generation_index"] == generation]
            if not rows:
                message = f"run {resolved_run_id!r} has no generation {generation}"
                if json_output:
                    write_json_stderr(message)
                else:
                    console.print(f"[red]{message}[/red]")
                raise typer.Exit(code=1)
        elif rows:
            rows = [max(rows, key=lambda r: r["generation_index"])]

        if not rows:
            message = f"run {resolved_run_id!r} has no generations yet"
            if json_output:
                write_json_stderr(message)
            else:
                console.print(f"[red]{message}[/red]")
            raise typer.Exit(code=1)

        rows, active_epoch_id = annotate_run_status_rows(
            settings,
            run.get("scenario"),
            rows,
            store,
            resolved_run_id,
        )

        if json_output:
            payload: dict[str, Any] = run_show_wire_payload(
                run,
                rows[0],
                run_id=resolved_run_id,
            )
            payload.update({
                # Compatibility fields retained for existing Python CLI consumers.
                "run_id": resolved_run_id,
                "scenario": run.get("scenario"),
                "status": run.get("status"),
                "active_evaluator_epoch": active_epoch_id,
                "generations": [
                    {
                        "generation": r["generation_index"],
                        "mean_score": r["mean_score"],
                        "best_score": r["best_score"],
                        "elo": r["elo"],
                        "wins": r["wins"],
                        "losses": r["losses"],
                        "gate_decision": r["gate_decision"],
                        "status": r["status"],
                        "evaluator_epoch": r.get("evaluator_epoch"),
                        "evaluator_epoch_status": r["evaluator_epoch_status"],
                        "quarantined": bool(r.get("quarantined")),
                        "has_active_revision": r["has_active_revision"],
                        "revised_score": r.get("revised_score"),
                        "revised_by": r.get("revised_by"),
                        "revised_at": r.get("revised_at"),
                    }
                    for r in rows
                ],
            })
            write_json_stdout(payload)
            return

        console.print(
            f"[bold]Run {resolved_run_id}[/bold]  scenario={run.get('scenario')!r}  status={run.get('status')!r}"
        )
        table = Table(title="Generations" + (" (best)" if best else ""))
        table.add_column("Gen")
        table.add_column("Mean")
        table.add_column("Best")
        table.add_column("Elo")
        table.add_column("W")
        table.add_column("L")
        table.add_column("Gate")
        table.add_column("Status")
        table.add_column("Lineage")
        table.add_column("Revised")
        for row in rows:
            table.add_row(
                str(row["generation_index"]),
                f"{row['mean_score']:.4f}",
                f"{row['best_score']:.4f}",
                f"{row['elo']:.2f}",
                str(row["wins"]),
                str(row["losses"]),
                row["gate_decision"],
                row["status"],
                _lineage_cell(row),
                _revised_cell(row),
            )
        console.print(table)
        warning = _stale_warning_line(rows, active_epoch_id)
        if warning is not None:
            console.print(warning)
        note = _revised_note_line(rows)
        if note is not None:
            console.print(note)

    @app.command()
    def watch(
        run_id: str | None = typer.Argument(None, metavar="RUN_ID", help="Run id to watch."),
        run_id_option: str | None = typer.Option(
            None,
            "--run-id",
            help="Named alternative to the run-id positional.",
        ),
        interval: float = typer.Option(2.0, "--interval", min=0.1, help="Poll interval in seconds"),
        ndjson_output: bool = typer.Option(False, "--ndjson", help="Emit newline-delimited JSON snapshots"),
        json_output: bool = typer.Option(False, "--json", help="Deprecated alias for --ndjson"),
    ) -> None:
        """Stream live status updates for an in-flight run."""
        load_settings = _cli_attr(dependency_module, "load_settings")
        sqlite_from_settings = _cli_attr(dependency_module, "_sqlite_from_settings")
        write_json_stderr = _cli_attr(dependency_module, "_write_json_stderr")

        stream_output = ndjson_output or json_output
        resolved_run_id = (run_id_option or run_id or "").strip()
        if not resolved_run_id:
            message = "`autoctx watch` requires <run-id>."
            if stream_output:
                write_json_stderr(message)
            else:
                console.print(f"[red]Error: {message}[/red]")
            raise typer.Exit(code=2)

        store = None
        try:
            settings = load_settings()
            store = sqlite_from_settings(settings)
            if store.get_run(resolved_run_id) is None:
                message = f"run {resolved_run_id!r} not found"
                if stream_output:
                    write_json_stderr(message)
                else:
                    console.print(f"[red]{message}[/red]")
                raise typer.Exit(code=1)
            _watch_run_until_terminal(
                store,
                run_id=resolved_run_id,
                interval=interval,
                stream_output=stream_output,
                console=console,
            )
        except typer.Exit:
            raise
        except KeyboardInterrupt as exc:
            raise typer.Exit(code=130) from exc
        except Exception as exc:
            if stream_output:
                write_json_stderr(str(exc))
            else:
                console.print(f"[red]Error: {exc}[/red]")
            raise typer.Exit(code=1) from exc
        finally:
            close = getattr(store, "close", None) if store is not None else None
            if callable(close):
                close()
