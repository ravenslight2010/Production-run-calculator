"""Task runner daemon for always-on evaluation.

Polls a SQLite-backed task queue, runs ImprovementLoop for each task,
and stores results. Designed to run as a long-lived background process.
"""

from __future__ import annotations

import concurrent.futures
import json
import logging
import signal
import time
import traceback
import uuid
from collections.abc import Callable
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from autocontext.notifications.base import Notifier

from autocontext.config.settings import AppSettings
from autocontext.execution.agent_task_completion import (
    NATIVE_AGENT_TASK_QUEUE_MARKER,
    TaskConfig,
    build_evaluator_guardrail_payload,
    build_objective_guardrail_payload,
    build_objective_payload,
    build_objective_revision_feedback,
    build_rubric_calibration_payload,
    compute_effective_met_threshold,
)
from autocontext.execution.agent_task_evolution import (
    AgentTaskEvolutionRunner,
    AgentTaskGenerationEvaluation,
    AgentTaskTrajectory,
    EvolutionWorkspace,
    WorkspaceEvaluateFn,
)
from autocontext.execution.evaluator_epoch_registry import observe_epoch_quarantined
from autocontext.execution.evaluator_guardrail import evaluate_evaluator_guardrail
from autocontext.execution.improvement_loop import ImprovementLoop, ImprovementResult
from autocontext.execution.judge import LLMJudge
from autocontext.execution.queued_task_browser_context import (
    QueuedTaskBrowserContextService,
    create_queued_task_browser_context_service,
)
from autocontext.execution.simple_agent_task_workflow import (
    generate_simple_agent_task_output,
    revise_simple_agent_task_output,
)
from autocontext.execution.task_queue_store import TaskQueueEnqueueStore, TaskQueueStore
from autocontext.execution.task_runner_workspaces import (
    evaluate_workspace_candidate as _evaluate_workspace_candidate,
)
from autocontext.execution.task_runner_workspaces import (
    workspace_factory_from_settings as _workspace_factory_from_settings,
)
from autocontext.providers.base import LLMProvider
from autocontext.scenarios.agent_task import AgentTaskInterface, AgentTaskResult
from autocontext.simplicity import normalize_simplicity_mode

logger = logging.getLogger(__name__)


def _serialize_result(
    result: ImprovementResult,
    objective_verification: dict[str, Any] | None = None,
    objective_guardrail: dict[str, Any] | None = None,
    evaluator_guardrail: dict[str, Any] | None = None,
    rubric_calibration: dict[str, Any] | None = None,
    quarantined: bool | None = None,
) -> str:
    """Serialize an ImprovementResult to JSON."""
    rounds = []
    for r in result.rounds:
        rounds.append(
            {
                "round_number": r.round_number,
                "score": r.score,
                "reasoning": r.reasoning,
                "dimension_scores": r.dimension_scores,
                "is_revision": r.is_revision,
                "evaluator_epoch": r.evaluator_epoch,
            }
        )
    data: dict[str, Any] = {
        "rounds": rounds,
        "best_score": result.best_score,
        "best_round": result.best_round,
        "total_rounds": result.total_rounds,
        "met_threshold": result.met_threshold,
        "evaluator_epoch": result.evaluator_epoch,
        "quarantined": quarantined,
    }
    if result.duration_ms is not None:
        data["duration_ms"] = result.duration_ms
    if result.judge_calls:
        data["judge_calls"] = result.judge_calls
    if objective_verification is not None:
        data["objective_verification"] = objective_verification
    if objective_guardrail is not None:
        data["objective_guardrail"] = objective_guardrail
    if evaluator_guardrail is not None:
        data["evaluator_guardrail"] = evaluator_guardrail
    if rubric_calibration is not None:
        data["rubric_calibration"] = rubric_calibration
    if result.pareto_frontier:
        data["pareto_frontier"] = result.pareto_frontier
    if result.actionable_side_info:
        data["actionable_side_info"] = result.actionable_side_info
    if result.metadata:
        data["optimizer_metadata"] = result.metadata
    return json.dumps(data)


def _serialize_evolution_result(
    trajectory: AgentTaskTrajectory,
    generation_results: list[ImprovementResult],
    objective_verification: dict[str, Any] | None = None,
    objective_guardrail: dict[str, Any] | None = None,
    evaluator_guardrail: dict[str, Any] | None = None,
    met_threshold: bool | None = None,
    rubric_calibration: dict[str, Any] | None = None,
    evaluator_epoch: str | None = None,
    quarantined: bool | None = None,
) -> str:
    """Serialize a multi-generation AgentTask evolution run to JSON."""
    final_rounds: list[dict[str, Any]] = []
    if generation_results:
        final_result = generation_results[-1]
        final_rounds = [
            {
                "round_number": r.round_number,
                "score": r.score,
                "reasoning": r.reasoning,
                "dimension_scores": r.dimension_scores,
                "is_revision": r.is_revision,
            }
            for r in final_result.rounds
        ]

    generation_summaries = [
        {
            "generation": idx + 1,
            "best_score": result.best_score,
            "best_round": result.best_round,
            "total_rounds": result.total_rounds,
            "met_threshold": result.met_threshold,
            **({"pareto_frontier": result.pareto_frontier} if result.pareto_frontier else {}),
            **({"actionable_side_info": result.actionable_side_info} if result.actionable_side_info else {}),
            **({"optimizer_metadata": result.metadata} if result.metadata else {}),
        }
        for idx, result in enumerate(generation_results)
    ]

    data: dict[str, Any] = {
        "mode": "agent_task_multi_generation",
        "trajectory": trajectory.to_dict(),
        "generations": generation_summaries,
        "rounds": final_rounds,
        "best_score": trajectory.metadata.get("best_score", trajectory.final_score),
        "met_threshold": (
            met_threshold if met_threshold is not None else any(result.met_threshold for result in generation_results)
        ),
        "total_rounds": sum(result.total_rounds for result in generation_results),
        "evaluator_epoch": evaluator_epoch,
        "quarantined": quarantined,
    }
    if objective_verification is not None:
        data["objective_verification"] = objective_verification
    if objective_guardrail is not None:
        data["objective_guardrail"] = objective_guardrail
    if evaluator_guardrail is not None:
        data["evaluator_guardrail"] = evaluator_guardrail
    if rubric_calibration is not None:
        data["rubric_calibration"] = rubric_calibration
    if generation_results:
        final_result = generation_results[-1]
        if final_result.pareto_frontier:
            data["pareto_frontier"] = final_result.pareto_frontier
        if final_result.actionable_side_info:
            data["actionable_side_info"] = final_result.actionable_side_info
        if final_result.metadata:
            data["optimizer_metadata"] = final_result.metadata
    return json.dumps(data)


class SimpleAgentTask(AgentTaskInterface):
    """A simple agent task built from config (no codegen needed).

    Used by the task runner when tasks are defined via queue config
    rather than registered scenario classes.
    """

    def __init__(
        self,
        task_prompt: str,
        rubric: str,
        provider: LLMProvider,
        model: str = "",
        revision_prompt: str | None = None,
        judge_samples: int = 1,
        judge_temperature: float = 0.0,
        judge_disagreement_threshold: float = 0.15,
        judge_bias_probes_enabled: bool = False,
        simplicity_mode: str = "off",
    ) -> None:
        self._task_prompt = task_prompt
        self._rubric = rubric
        self._provider = provider
        self._model = model
        self._revision_prompt = revision_prompt
        self._judge_samples = judge_samples
        self._judge_temperature = judge_temperature
        self._judge_disagreement_threshold = judge_disagreement_threshold
        self._judge_bias_probes_enabled = judge_bias_probes_enabled
        self._simplicity_mode = normalize_simplicity_mode(simplicity_mode)

    def get_task_prompt(self, state: dict) -> str:
        return self._task_prompt

    def get_rubric(self) -> str:
        return self._rubric

    def initial_state(self, seed: int | None = None) -> dict:
        return {}

    def describe_task(self) -> str:
        return self._task_prompt

    def evaluate_output(
        self,
        output: str,
        state: dict,
        reference_context: str | None = None,
        required_concepts: list[str] | None = None,
        calibration_examples: list[dict] | None = None,
        pinned_dimensions: list[str] | None = None,
    ) -> AgentTaskResult:
        effective_model = self._model or self._provider.default_model()
        judge = LLMJudge(
            model=effective_model,
            rubric=self._rubric,
            provider=self._provider,
            samples=self._judge_samples,
            temperature=self._judge_temperature,
            disagreement_threshold=self._judge_disagreement_threshold,
        )
        judge_result = judge.evaluate(
            task_prompt=self._task_prompt,
            agent_output=output,
            reference_context=reference_context,
            required_concepts=required_concepts,
            calibration_examples=calibration_examples,
            pinned_dimensions=pinned_dimensions,
        )
        evaluator_guardrail = evaluate_evaluator_guardrail(
            judge_result,
            provider=self._provider,
            model=effective_model,
            rubric=self._rubric,
            candidate_output=output,
            bias_probes_enabled=self._judge_bias_probes_enabled,
        )
        return AgentTaskResult(
            score=judge_result.score,
            reasoning=judge_result.reasoning,
            dimension_scores=judge_result.dimension_scores,
            internal_retries=judge_result.internal_retries,
            evaluator_guardrail=(evaluator_guardrail.to_dict() if evaluator_guardrail is not None else None),
            evaluator_epoch=judge_result.evaluator_epoch,
        )

    def generate_output(self, state: dict) -> str:
        """Generate initial output using the provider."""
        return generate_simple_agent_task_output(
            provider=self._provider,
            model=self._model,
            task_prompt=self._task_prompt,
            reference_context=state.get("reference_context"),
            required_concepts=state.get("required_concepts"),
            simplicity_mode=self._simplicity_mode,
        )

    def revise_output(self, output: str, judge_result: AgentTaskResult, state: dict) -> str:
        """Revise output using judge feedback."""
        objective_feedback = state.get("oracle_revision_feedback_context")
        return revise_simple_agent_task_output(
            provider=self._provider,
            model=self._model,
            task_prompt=self._task_prompt,
            output=output,
            judge_result=judge_result,
            revision_prompt=self._revision_prompt,
            reference_context=state.get("reference_context"),
            required_concepts=state.get("required_concepts"),
            objective_feedback=(objective_feedback if isinstance(objective_feedback, str) else None),
            simplicity_mode=self._simplicity_mode,
        )


class TaskRunner:
    """Daemon that polls the task queue and runs improvement loops.

    Usage::

        runner = TaskRunner(store=store, provider=provider)
        runner.run()  # Blocks until shutdown signal
    """

    def __init__(
        self,
        store: TaskQueueStore,
        provider: LLMProvider,
        model: str = "",
        poll_interval: float = 60.0,
        max_consecutive_empty: int = 0,  # 0 = run forever
        notifier: Notifier | None = None,
        concurrency: int = 1,
        browser_context_service: QueuedTaskBrowserContextService | None = None,
        settings: AppSettings | None = None,
        max_attempts: int = 3,
        retry_backoff_s: float = 30.0,
        stale_running_after_s: float = 3600.0,
        workspace_factory: Callable[[], EvolutionWorkspace] | None = None,
        workspace_evaluate_fn: WorkspaceEvaluateFn | None = None,
    ) -> None:
        self.store = store
        dequeue_for_python_worker = getattr(store, "dequeue_task_for_python_worker", None)
        if not callable(dequeue_for_python_worker):
            msg = "TaskRunner requires a store with dequeue_task_for_python_worker()"
            raise TypeError(msg)
        self._dequeue_for_python_worker: Callable[[], dict[str, Any] | None] = dequeue_for_python_worker
        self.provider = provider
        self.model = model
        self.poll_interval = poll_interval
        self.max_consecutive_empty = max_consecutive_empty
        self.notifier = notifier
        self.concurrency = max(1, concurrency)
        self.browser_context_service = browser_context_service
        self.settings = settings
        # AC-906: transient failures retry up to max_attempts claims; a crash
        # between claim and completion is recovered at startup.
        self.max_attempts = max(1, max_attempts)
        self.retry_backoff_s = retry_backoff_s
        self.stale_running_after_s = stale_running_after_s
        self.workspace_factory = workspace_factory or _workspace_factory_from_settings(settings)
        if workspace_evaluate_fn is not None and self.workspace_factory is None:
            raise ValueError("workspace_evaluate_fn requires a workspace_factory or enabled workspace setting")
        self.workspace_evaluate_fn = workspace_evaluate_fn
        self.workspace_execute_candidates = bool(
            settings is not None and settings.workspace_interpreter_execute_candidates and workspace_evaluate_fn is None
        )
        if self.workspace_execute_candidates and self.workspace_factory is None:
            raise ValueError("workspace candidate execution requires an enabled workspace")
        self._shutdown = False
        self._tasks_processed = 0

    def _observe_epoch_quarantine(self, scenario: str, epoch_id: str | None) -> bool | None:
        """Observe the task's evaluator epoch and report whether its score is quarantined.

        The queue result JSON is the always-on surface for TaskRunner (it does not write the
        ``generations`` table); this is where its scores enter the epoch lifecycle. Requires
        ``settings`` for the registry root; without it the marker is simply omitted.
        """
        if self.settings is None:
            return None
        return observe_epoch_quarantined(self.settings.knowledge_root / "_evaluator_epochs", scenario, epoch_id)

    def run(self) -> int:
        """Main loop. Returns the number of tasks processed.

        When ``concurrency`` > 1, uses :meth:`run_batch` to process
        multiple tasks in parallel via a thread pool.
        """
        self._setup_signals()
        # AC-906: guarded so external store implementations that predate the
        # protocol addition degrade gracefully instead of crashing at startup.
        sweep = getattr(self.store, "requeue_stale_running", None)
        if callable(sweep):
            recovered = sweep(older_than_seconds=self.stale_running_after_s, max_attempts=self.max_attempts)
            if recovered:
                logger.info("recovered %d crash-stranded running task(s)", recovered)
        consecutive_empty = 0

        logger.info(
            "task runner started (poll_interval=%.1fs, concurrency=%d)",
            self.poll_interval,
            self.concurrency,
        )

        while not self._shutdown:
            processed = self.run_batch(self.concurrency)

            if processed == 0:
                consecutive_empty += 1
                if self.max_consecutive_empty > 0 and consecutive_empty >= self.max_consecutive_empty:
                    logger.info("max consecutive empty polls reached, shutting down")
                    break
                logger.debug("no tasks, sleeping %.1fs", self.poll_interval)
                self._sleep(self.poll_interval)
                continue

            consecutive_empty = 0

        logger.info("task runner stopped. processed %d tasks", self._tasks_processed)
        return self._tasks_processed

    def run_once(self) -> dict[str, Any] | None:
        """Process a single task from the queue. Returns the task dict or None."""
        task = self._dequeue_for_python_worker()
        if task is None:
            return None
        self._process_task(task)
        self._tasks_processed += 1
        return self.store.get_task(task["id"])

    def run_batch(self, limit: int | None = None) -> int:
        """Process up to *limit* (default: ``self.concurrency``) tasks concurrently.

        Uses ``concurrent.futures.ThreadPoolExecutor`` so that each task
        runs in its own thread.  Returns the number of tasks successfully
        processed (failed tasks are not counted).
        """
        max_tasks = limit if limit is not None else self.concurrency
        tasks: list[dict[str, Any]] = []
        for _ in range(max_tasks):
            task = self._dequeue_for_python_worker()
            if task is None:
                break
            tasks.append(task)
        if not tasks:
            return 0

        succeeded = 0
        if len(tasks) == 1:
            # Skip thread pool overhead for single tasks
            try:
                self._process_task(tasks[0])
                succeeded = 1
            except Exception:
                logger.exception("task %s raised", tasks[0].get("id", "?"))
        else:
            with concurrent.futures.ThreadPoolExecutor(max_workers=len(tasks)) as pool:
                futures = {pool.submit(self._process_task, t): t for t in tasks}
                for future in concurrent.futures.as_completed(futures):
                    task = futures[future]
                    try:
                        future.result()
                        succeeded += 1
                    except Exception:
                        logger.exception("task %s raised in batch", task.get("id", "?"))

        self._tasks_processed += succeeded
        return succeeded

    def shutdown(self) -> None:
        """Signal the runner to stop after current task completes."""
        self._shutdown = True

    def _process_task(self, task: dict[str, Any]) -> None:
        task_id = task["id"]
        spec_name = task["spec_name"]
        logger.info("processing task %s (spec=%s)", task_id, spec_name)

        try:
            config = TaskConfig.from_json(task.get("config_json"))
            if config.has_native_task_metadata:
                msg = (
                    f"Queued task '{spec_name}' contains native saved-task metadata and must be "
                    f"processed by the TypeScript worker ({NATIVE_AGENT_TASK_QUEUE_MARKER}); "
                    "Python SimpleAgentTask execution is disabled to preserve evaluator isolation"
                )
                raise ValueError(msg)
            reference_context = self._resolve_reference_context(task_id, config)

            agent_task = SimpleAgentTask(
                task_prompt=config.task_prompt or f"Complete the task: {spec_name}",
                rubric=config.rubric or "Evaluate quality, accuracy, and completeness on a 0-1 scale.",
                provider=self.provider,
                model=self.model,
                revision_prompt=config.revision_prompt,
                judge_samples=config.judge_samples,
                judge_temperature=config.judge_temperature,
                judge_disagreement_threshold=config.judge_disagreement_threshold,
                judge_bias_probes_enabled=config.judge_bias_probes_enabled,
                simplicity_mode=config.simplicity_mode,
            )

            # Generate initial output if not provided
            initial_output = config.initial_output
            if not initial_output:
                logger.info("generating initial output for task %s", task_id)
                initial_output = agent_task.generate_output(
                    {
                        "reference_context": reference_context,
                        "required_concepts": config.required_concepts,
                    }
                )
            if config.generations > 1:
                result = self._run_task_multi_generation(
                    task_id=task_id,
                    agent_task=agent_task,
                    spec_name=spec_name,
                    initial_output=initial_output,
                    config=config,
                    reference_context=reference_context,
                )
            else:
                loop = ImprovementLoop(
                    task=agent_task,
                    max_rounds=config.max_rounds,
                    quality_threshold=config.quality_threshold,
                    min_rounds=config.min_rounds,
                )
                loop_state: dict[str, Any] = {
                    "reference_context": reference_context,
                    "required_concepts": config.required_concepts,
                }
                if config.objective_verification:
                    loop_state["revision_feedback_callback"] = lambda current_output, judge_result: (
                        build_objective_revision_feedback(
                            current_output,
                            judge_result.score,
                            config,
                        )
                    )

                result = loop.run(
                    initial_output=initial_output,
                    state=loop_state,
                    reference_context=reference_context,
                    required_concepts=config.required_concepts,
                    calibration_examples=config.calibration_examples,
                )
                objective_payload, objective_guardrail, evaluator_guardrail, effective_met_threshold, rubric_calibration = (
                    self._finalize_task_output(
                        agent_task=agent_task,
                        task_id=task_id,
                        spec_name=spec_name,
                        best_output=result.best_output,
                        best_score=result.best_score,
                        met_threshold=result.met_threshold,
                        reference_context=reference_context,
                        config=config,
                    )
                )
                result.met_threshold = effective_met_threshold

                epoch_id = getattr(result, "evaluator_epoch", None)
                quarantined = self._observe_epoch_quarantine(spec_name, epoch_id)
                self.store.complete_task(
                    task_id=task_id,
                    best_score=result.best_score,
                    best_output=result.best_output,
                    total_rounds=result.total_rounds,
                    met_threshold=effective_met_threshold,
                    result_json=_serialize_result(
                        result,
                        objective_payload,
                        objective_guardrail,
                        evaluator_guardrail,
                        rubric_calibration,
                        quarantined=quarantined,
                    ),
                )

            logger.info(
                "task %s completed: score=%.2f rounds=%d threshold_met=%s",
                task_id,
                result.best_score,
                result.total_rounds,
                result.met_threshold,
            )

            self._emit_completion_event(task_id, spec_name, result)

        except Exception:
            logger.exception("task %s failed", task_id)
            error_msg = traceback.format_exc()
            self.store.fail_task(task_id, error_msg, max_attempts=self.max_attempts, retry_backoff_s=self.retry_backoff_s)
            self._emit_failure_event(task_id, spec_name, error_msg)

    def _run_task_multi_generation(
        self,
        task_id: str,
        agent_task: SimpleAgentTask,
        spec_name: str,
        initial_output: str,
        config: TaskConfig,
        reference_context: str | None = None,
    ) -> ImprovementResult:
        """Run first-class multi-generation learning for an AgentTask."""
        generation_results: dict[int, ImprovementResult] = {}

        def generate_fn(prompt: str, generation: int) -> str:
            if self.workspace_execute_candidates:
                prompt = (
                    f"{prompt}\n\nReturn executable Python source only. The program must produce the "
                    "task answer through stdout or the `answer` mapping."
                )
            return generate_simple_agent_task_output(
                provider=self.provider,
                model=self.model or self.provider.default_model(),
                task_prompt=prompt,
                reference_context=reference_context,
                required_concepts=config.required_concepts,
            )

        def evaluate_fn(output: str, generation: int) -> AgentTaskGenerationEvaluation:
            loop = ImprovementLoop(
                task=agent_task,
                max_rounds=config.max_rounds,
                quality_threshold=config.quality_threshold,
                min_rounds=config.min_rounds,
            )
            loop_state: dict[str, Any] = {
                "reference_context": reference_context,
                "required_concepts": config.required_concepts,
            }
            if config.objective_verification:
                loop_state["revision_feedback_callback"] = lambda current_output, judge_result: build_objective_revision_feedback(
                    current_output,
                    judge_result.score,
                    config,
                )
            loop_result = loop.run(
                initial_output=output,
                state=loop_state,
                reference_context=reference_context,
                required_concepts=config.required_concepts,
                calibration_examples=config.calibration_examples,
            )
            generation_results[generation] = loop_result
            best_round_result = next(
                (round_result for round_result in loop_result.rounds if round_result.round_number == loop_result.best_round),
                loop_result.rounds[-1],
            )
            return AgentTaskGenerationEvaluation(
                output=loop_result.best_output,
                score=loop_result.best_score,
                reasoning=best_round_result.reasoning,
                dimension_scores=best_round_result.dimension_scores,
                round_count=loop_result.total_rounds,
                met_threshold=loop_result.met_threshold,
                metadata={
                    "best_round": loop_result.best_round,
                    "judge_failures": loop_result.judge_failures,
                },
            )

        def evaluate_workspace_candidate(
            program: str,
            generation: int,
            workspace: EvolutionWorkspace,
        ) -> AgentTaskGenerationEvaluation:
            evaluation, improvement = _evaluate_workspace_candidate(
                program,
                workspace,
                evaluate_output=agent_task.evaluate_output,
                quality_threshold=config.quality_threshold,
                reference_context=reference_context,
                required_concepts=config.required_concepts,
                calibration_examples=config.calibration_examples,
            )
            generation_results[generation] = improvement
            return evaluation

        live_workspace_evaluator = self.workspace_evaluate_fn
        if live_workspace_evaluator is None and self.workspace_execute_candidates:
            live_workspace_evaluator = evaluate_workspace_candidate

        evolution = AgentTaskEvolutionRunner(
            task_prompt=agent_task.get_task_prompt({}),
            generate_fn=generate_fn,
            evaluate_fn=evaluate_fn,
            initial_output="" if self.workspace_execute_candidates else initial_output,
            task_name=spec_name,
            workspace_factory=self.workspace_factory,
            workspace_evaluate_fn=live_workspace_evaluator,
        )
        trajectory, state = evolution.run_with_state(config.generations)

        ordered_results = [generation_results[idx] for idx in sorted(generation_results)]
        total_rounds = sum(result.total_rounds for result in ordered_results)
        met_threshold = any(result.met_threshold for result in ordered_results)
        best_score = state.best_score
        best_output = state.best_output
        best_generation = max(
            ordered_results,
            key=lambda result: result.best_score,
        )
        finalization_output = best_output
        workspace_execution = best_generation.metadata.get("workspace_execution")
        if self.workspace_execute_candidates and isinstance(workspace_execution, dict):
            observed_output = workspace_execution.get("observed_output")
            if isinstance(observed_output, str):
                finalization_output = observed_output
        objective_payload, objective_guardrail, evaluator_guardrail, effective_met_threshold, rubric_calibration = (
            self._finalize_task_output(
                agent_task=agent_task,
                task_id=task_id,
                spec_name=spec_name,
                best_output=finalization_output,
                best_score=best_score,
                met_threshold=met_threshold,
                reference_context=reference_context,
                config=config,
            )
        )

        # The multi-generation aggregate persists best_generation's score; carry its epoch so the
        # queue result JSON (and the returned result) keep the epoch + quarantine lineage.
        epoch_id = best_generation.evaluator_epoch
        quarantined = self._observe_epoch_quarantine(spec_name, epoch_id)

        self.store.complete_task(
            task_id=task_id,
            best_score=best_score,
            best_output=best_output,
            total_rounds=total_rounds,
            met_threshold=effective_met_threshold,
            result_json=_serialize_evolution_result(
                trajectory,
                ordered_results,
                objective_payload,
                objective_guardrail,
                evaluator_guardrail,
                effective_met_threshold,
                rubric_calibration,
                evaluator_epoch=epoch_id,
                quarantined=quarantined,
            ),
        )

        return ImprovementResult(
            rounds=best_generation.rounds,
            best_output=best_output,
            best_score=best_score,
            best_round=best_generation.best_round,
            total_rounds=total_rounds,
            met_threshold=effective_met_threshold,
            judge_failures=sum(result.judge_failures for result in ordered_results),
            termination_reason="threshold_met" if effective_met_threshold else "max_rounds",
            total_internal_retries=sum(result.total_internal_retries for result in ordered_results),
            duration_ms=sum(result.duration_ms or 0 for result in ordered_results),
            judge_calls=sum(result.judge_calls for result in ordered_results),
            dimension_trajectory={},
            evaluator_epoch=epoch_id,
        )

    def _finalize_task_output(
        self,
        *,
        agent_task: SimpleAgentTask,
        task_id: str,
        spec_name: str,
        best_output: str,
        best_score: float,
        met_threshold: bool,
        reference_context: str | None,
        config: TaskConfig,
    ) -> tuple[dict[str, Any] | None, dict[str, Any] | None, dict[str, Any] | None, bool, dict[str, Any] | None]:
        """Assemble the objective/guardrail/calibration payload pieces shared by
        the single- and multi-generation task-completion paths.

        Returns (objective_payload, objective_guardrail, evaluator_guardrail,
        effective_met_threshold, rubric_calibration).
        """
        objective_payload = build_objective_payload(
            best_output,
            best_score,
            config,
            run_id=task_id,
        )
        objective_guardrail = build_objective_guardrail_payload(
            objective_payload,
            config,
        )
        evaluator_guardrail = build_evaluator_guardrail_payload(
            agent_task,
            best_output,
            config,
            reference_context=reference_context,
        )
        effective_met_threshold = compute_effective_met_threshold(
            met_threshold,
            objective_guardrail,
            evaluator_guardrail,
        )
        rubric_calibration = build_rubric_calibration_payload(
            store=self.store,
            spec_name=spec_name,
            task_prompt=agent_task.get_task_prompt({}),
            rubric=agent_task.get_rubric(),
            provider=self.provider,
            model=self.model,
            reference_context=reference_context,
            required_concepts=config.required_concepts,
        )
        return objective_payload, objective_guardrail, evaluator_guardrail, effective_met_threshold, rubric_calibration

    def _resolve_reference_context(self, task_id: str, config: TaskConfig) -> str | None:
        """Resolve authoritative reference context for a queued task."""
        if not config.browser_url:
            return config.reference_context
        if self.browser_context_service is None:
            raise ValueError("browser exploration is not configured")
        return self.browser_context_service.build_reference_context(
            task_id=task_id,
            browser_url=config.browser_url,
            reference_context=config.reference_context,
        )

    def _emit_completion_event(self, task_id: str, spec_name: str, result: ImprovementResult) -> None:
        if not self.notifier:
            return
        try:
            from autocontext.notifications.base import EventType, NotificationEvent

            event_type = EventType.THRESHOLD_MET if result.met_threshold else EventType.COMPLETION
            event = NotificationEvent(
                type=event_type,
                task_name=spec_name,
                task_id=task_id,
                score=result.best_score,
                round_count=result.total_rounds,
                output_preview=result.best_output[:500] if result.best_output else "",
            )
            self.notifier.notify(event)
        except Exception as exc:
            logger.warning("notification failed: %s", exc)

    def _emit_failure_event(self, task_id: str, spec_name: str, error: str) -> None:
        if not self.notifier:
            return
        try:
            from autocontext.notifications.base import EventType, NotificationEvent

            event = NotificationEvent(
                type=EventType.FAILURE,
                task_name=spec_name,
                task_id=task_id,
                error=error,
            )
            self.notifier.notify(event)
        except Exception as exc:
            logger.warning("notification failed: %s", exc)

    def _setup_signals(self) -> None:
        """Register signal handlers for graceful shutdown."""
        try:
            signal.signal(signal.SIGINT, self._handle_signal)
            signal.signal(signal.SIGTERM, self._handle_signal)
        except (OSError, ValueError):
            # Can't set signals in non-main thread or some environments
            pass

    def _handle_signal(self, signum: int, frame: Any) -> None:
        logger.info("received signal %d, shutting down after current task", signum)
        self._shutdown = True

    def _sleep(self, seconds: float) -> None:
        """Interruptible sleep."""
        end = time.monotonic() + seconds
        while time.monotonic() < end and not self._shutdown:
            time.sleep(min(1.0, end - time.monotonic()))


def create_task_runner_from_settings(
    settings: AppSettings,
    *,
    store: TaskQueueStore,
    provider: LLMProvider,
    model: str = "",
    poll_interval: float = 60.0,
    max_consecutive_empty: int = 0,
    notifier: Notifier | None = None,
    concurrency: int = 1,
) -> TaskRunner:
    """Build a task runner from app settings with optional browser enrichment."""
    browser_context_service = create_queued_task_browser_context_service(settings) if settings.browser_enabled else None
    return TaskRunner(
        store=store,
        provider=provider,
        model=model,
        poll_interval=poll_interval,
        max_consecutive_empty=max_consecutive_empty,
        notifier=notifier,
        concurrency=concurrency,
        browser_context_service=browser_context_service,
        settings=settings,
    )


def enqueue_task(
    store: TaskQueueEnqueueStore,
    spec_name: str,
    task_prompt: str | None = None,
    rubric: str | None = None,
    reference_context: str | None = None,
    browser_url: str | None = None,
    required_concepts: list[str] | None = None,
    generations: int = 1,
    max_rounds: int = 5,
    quality_threshold: float = 0.9,
    min_rounds: int = 1,
    initial_output: str | None = None,
    objective_verification: dict[str, Any] | None = None,
    judge_samples: int = 1,
    judge_temperature: float = 0.0,
    judge_disagreement_threshold: float = 0.15,
    judge_bias_probes_enabled: bool = False,
    priority: int = 0,
) -> str:
    """Convenience function to enqueue a task. Returns the task ID."""
    task_id = str(uuid.uuid4())
    config = {
        "generations": generations,
        "max_rounds": max_rounds,
        "quality_threshold": quality_threshold,
        "min_rounds": min_rounds,
        "task_prompt": task_prompt,
        "rubric": rubric,
        "reference_context": reference_context,
        "browser_url": browser_url,
        "required_concepts": required_concepts,
        "initial_output": initial_output,
        "objective_verification": objective_verification,
        "judge_samples": judge_samples,
        "judge_temperature": judge_temperature,
        "judge_disagreement_threshold": judge_disagreement_threshold,
        "judge_bias_probes_enabled": judge_bias_probes_enabled,
    }
    # Remove None values
    config = {k: v for k, v in config.items() if v is not None}
    store.enqueue_task(task_id=task_id, spec_name=spec_name, priority=priority, config=config)
    return task_id
