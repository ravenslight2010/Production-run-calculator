# Contributing

## Setup

Python work happens in `autocontext/`:

```bash
cd autocontext
uv venv
source .venv/bin/activate
uv sync --group dev
```

Optional extras:

```bash
uv sync --group dev --extra mcp
uv sync --group dev --extra mlx
uv sync --group dev --extra monty
```

TypeScript work happens in `ts/`:

```bash
cd ts
npm install
```

The TypeScript package requires Node 22.19.0 or newer. Native modules
(`isolated-vm`, `better-sqlite3`) and pi-tui share the version pinned in
`ts/.nvmrc` (also applies to `pi/`, which depends on `ts/`).

## Common Checks

Python:

```bash
cd autocontext
uv run ruff check src tests
uv run mypy src
uv run pytest
uv run python ../scripts/check_markdown_links.py
```

Python CI runs four module-preserving shards, balanced by collected test count.
To reproduce one shard from `autocontext/`, run
`uv run python scripts/pytest_shard.py 1/4 -m "not live"`.
Each shard retains JUnit timings and coverage data; the required `test` job
checks all shards and combines their coverage into the existing report.
Dependency caches remain disabled in public workflows.

TypeScript:

```bash
cd ts
npm run lint
npm test
```

TUI-related TypeScript work:

```bash
cd ts
npm install
npm test
```

## Repo Map

- `autocontext/`: Python package, CLI, API server, and tests
- `ts/`: published TypeScript package, Node CLI, MCP server, and bundled pi-tui terminal UI
- `scripts/`: repo maintenance and protocol generation helpers

## Development Notes

- The Python package name and CLI are `autocontext` / `autoctx`.
- Environment variables use the `AUTOCONTEXT_` prefix.
- Prefer targeted tests for touched modules before running full suites.
- Use parity-last changes: implement one runtime first unless cross-runtime parity is user-visible in the same release. Note deferred parity in the PR.
- Keep protocol changes in sync with `scripts/generate_protocol.py`.
- Keep repository-relative Markdown paths and heading anchors valid with
  `scripts/check_markdown_links.py`. The deterministic check skips external URL
  availability plus generated run/knowledge artifacts, test fixtures/goldens,
  dependencies, caches, and build outputs.
- Keep proposed context and harness artifacts out of live paths. Use immutable
  context bundles and matched confirmation for activation; a strategy gate is
  not evidence for a context edit that the strategy did not exercise.
- Avoid rewriting historical plan docs unless the change is user-facing or release-facing.
- Use `autoctx scenario create` and `autoctx serve mcp` in public examples; reserve
  legacy aliases for explicitly labeled compatibility documentation.

## Documentation Touch Points

When a change affects public commands, environment variables, package names, or agent-facing workflows, update the relevant docs in the same PR:

- `README.md`
- `docs/README.md`
- `autocontext/README.md`
- `ts/README.md`
- `examples/README.md`
- `autocontext/docs/agent-integration.md`
- `AGENTS.md`
- `CHANGELOG.md`

## Releases

Publishing is split by package and uses GitHub OIDC trusted publishing rather than long-lived PyPI or npm tokens.

- Python publishes through `.github/workflows/publish-python.yml`
  - tag trigger: `py-v<version>`
  - manual trigger: `workflow_dispatch` from `main`
  - environment: `publish-python`
- TypeScript publishes through `.github/workflows/publish-ts.yml`
  - tag trigger: `ts-v<version>`
  - manual trigger: `workflow_dispatch` from `main`
  - environment: `publish-ts`
- Pi extension publishes through `.github/workflows/publish-pi-autocontext.yml`
  - tag trigger: `pi-v<version>`
  - manual trigger: `workflow_dispatch` from `main`
  - environment: `publish-pi-autocontext`

Release notes:

- Keep the GitHub environment branch/tag policy restricted to `main` and the matching tag namespace.
- Merge release preparation into protected `main` and wait for CI on that exact
  commit before creating a release tag. The release guard is loaded from `main`,
  verifies that the release commit belongs to its history, and requires a
  successful main-push CI run with `lint`, `test`, `smoke`,
  `dependency-security`, `ts-lint`, and `ts-test` from GitHub Actions.
- Release tags are immutable and may be created only by the configured release
  maintainers. A different configured reviewer must approve publication;
  publishing environments prohibit self-approval and administrator bypass.
- The trusted publisher registration in PyPI and npm must match the repo, workflow filename, and environment name exactly.
- No `NPM_TOKEN`, `NODE_AUTH_TOKEN`, or PyPI API token should be required for the publish jobs.
- After cutover, remove the old combined `.github/workflows/publish.yml` publisher registration from PyPI and npm.

## Live Service Verification

Live PrimeIntellect checks run through the manual `live-integration` workflow
from `main`. They do not run on pull requests or automatically after merges.
Review the dispatched commit and approve the `live-integration` environment
using a different configured reviewer from the person who started the run.

Before enabling live checks, configure `AUTOCONTEXT_PRIMEINTELLECT_API_KEY` and
`AUTOCONTEXT_ANTHROPIC_API_KEY` as secrets of that environment. Do not expose
these keys as repository-wide or inherited organization secrets. Missing keys
fail the manual run. The optional accelerator check uses the existing
`AUTOCONTEXT_PRIMEINTELLECT_LIVE_*` environment variables.

Dependency setup receives no service-key environment variables. Only the live
commands receive the keys, and `uv run --no-sync` avoids reinstalling packages
while they are present. This limits accidental exposure; all reviewed code in
the job is still trusted, because step boundaries do not isolate malicious
background processes.

## Type System Conventions

### ABC vs Protocol

- **ABC** — for internal class hierarchies where subclasses share implementation via inheritance (e.g., `ScenarioInterface`, `LLMProvider`, `AgentRuntime`, `Notifier`)
- **Protocol** — for duck-typed integration points where implementors shouldn't need to import the base class (e.g., `ExecutionEngine`, `Evaluator`, `DictSerializable`, `ReplWorkerProtocol`)
- New root ABCs (`class X(ABC)`) should define at least one `@abstractmethod`; subclasses that inherit an abstract contract from another ABC do not need to redeclare one.

### Dict types

- Use `dict[str, Any]` for JSON-like dicts (not `dict[str, object]`)
- Prefer `TypedDict` when the dict shape is known at all call sites
- Use `Mapping[str, Any]` for read-only dict parameters

### Collection parameters

- Use `Sequence[X]` for read-only list parameters in public API functions
- Use `list[X]` for return types and parameters that are mutated
- Use `Mapping[str, X]` for read-only dict parameters (already used in `ScenarioInterface`)

### Type aliases

- `LlmFn = Callable[[str, str], str]` — defined in `agents/types.py`
- Use `from enum import StrEnum` (not `import enum` + `enum.StrEnum`)

### Logger naming

- Use `logger = logging.getLogger(__name__)` (lowercase, per PEP 8)

## Pull Requests

- Keep changes scoped to one feature or cleanup theme.
- Update docs and examples when renaming commands, env vars, or package paths.
- Include verification notes for the checks you ran.
