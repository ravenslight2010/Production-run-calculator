# @workspace/distill-dataset

Git-safe distillation **manifest** types + validators, and train-safety checks for sequence-level QLoRA datasets.

## Install into monorepo

```bash
# from repo root
cp -R path/to/lib-distill-dataset lib/distill-dataset
# wire package into pnpm workspace if not auto-picked (see pnpm-workspace.yaml)
pnpm install
pnpm --filter @workspace/distill-dataset test
pnpm --filter @workspace/distill-dataset typecheck
```

## API

| Export | Purpose |
|--------|---------|
| `validateDistillManifestEntry` | Public/git row (hashes + metadata only) |
| `validateDistillTrainingExample` | Private example including `messages` |
| `assessTrainSafety` | Hard rejects: bad JSON, fences, blank-poison, verification, dup/leak flags |
| `assertBrandPartitionIntegrity` | No brand in two of train/dev/holdout |
| `toManifestEntry` | Strip messages for git manifest |

## Privacy

- **Repo:** manifest entries only (`contentSha256`, brand, partition, verified).
- **Private store:** full `messages` with pinned production system prompt + assistant JSON.

## Not included (by design)

- Near-duplicate similarity implementation (call site supplies `nearDuplicateOfHoldout`)
- Apply-log backfill scripts
- Unsloth training runner

See research docs: `qlora-unsloth-config-and-train-checklist-2026-09-28.md`.
