---
command: develop
disable-model-invocation: true
description: "Development phase - Build solutions with multi-AI implementation and quality gates"
aliases:
  - tangle
  - build-phase
---

# Develop - Development Phase 🛠️

Load `skills/blocks/engineering-method-selection.md` from the installed plugin
and apply only the methods relevant to this task. Preserve this entry point's
execution contract and output format. Read referenced skills as instructions;
do not invoke the current command recursively or add provider calls from a seat.

## 🤖 INSTRUCTIONS FOR CLAUDE

### MANDATORY COMPLIANCE — DO NOT SKIP

**When the user explicitly invokes `/octo:develop`, you MUST execute the structured workflow below.** You are PROHIBITED from doing the task directly, skipping the development phase with quality gates, or deciding the task is "too simple" for this workflow. The user chose this command deliberately — respect that choice.

### EXECUTION MECHANISM — NON-NEGOTIABLE

**You MUST execute this command via the Bash tool calling `orchestrate.sh develop`. You are PROHIBITED from:**
- Using `Skill(skill: "octo:develop")` because it resolves back to this file and loops
- Using `Skill(skill: "flow-develop", ...)` because that internal name is not resolvable by the Skill tool
- Using the Agent tool, WebFetch, Read, or Grep as a substitute for multi-provider dispatch
- Skipping `orchestrate.sh` calls because "I can do this faster directly"
- Implementing the task using only Claude-native tools

**Multi-LLM orchestration is the purpose of this command.** If you execute using only Claude, you've violated the command's contract.

---

When the user invokes this command (e.g., `/octo:develop <arguments>`):

**Preflight — Ensure plugin root is resolvable (run via Bash tool FIRST):**

```bash
OCTO_ROOT="${HOME}/.claude-octopus/plugin"
if [[ ! -x "$OCTO_ROOT/scripts/orchestrate.sh" ]]; then
  helper="$OCTO_ROOT/scripts/helpers/ensure-plugin-root.sh"
  if [[ ! -x "$helper" ]]; then
    helper="$(find "${HOME}/.claude/plugins/cache" "${HOME}/Library/Application Support/Claude" "${LOCALAPPDATA:-/dev/null}/Claude" "${XDG_DATA_HOME:-${HOME}/.local/share}/Claude" -maxdepth 8 -path "*/nyldn-plugins/octo/*/scripts/helpers/ensure-plugin-root.sh" -print -quit 2>/dev/null)"
  fi
  [[ -x "$helper" ]] && bash "$helper" >/dev/null 2>&1 || true
fi
test -x "$OCTO_ROOT/scripts/orchestrate.sh" && echo "plugin-root:ok" || echo "plugin-root:missing"
```

If the output is `plugin-root:missing`, stop and ask the user to run `/octo:setup`.

**Step 1 — Run provider preflight via Bash tool:**

```bash
bash "${HOME}/.claude-octopus/plugin/scripts/helpers/check-providers.sh"
```

Use the actual preflight output to display the workflow indicator before dispatch:

```text
🐙 **CLAUDE OCTOPUS ACTIVATED** - Multi-provider implementation mode
```

List available providers and mark missing providers as `(unavailable - skipping)`. If `OCTOPUS_COMPACT_BANNERS=true`, use this compact single-line format:

```text
🐙 develop — Multi-provider implementation mode | codex ✓ | agy (unavailable - skipping)
```

If no external provider is available, stop and tell the user to run `/octo:setup`; do not fall back to Claude-native implementation.

**Step 2 — Run orchestrate.sh via Bash tool:**

```bash
bash "${HOME}/.claude-octopus/plugin/scripts/orchestrate.sh" develop "<user's arguments here>"
```

**✗ INCORRECT:**

```text
Skill(skill: "octo:develop", ...)  ❌ Resolves to this command file — infinite loop
Skill(skill: "flow-develop", ...)  ❌ Internal name, not resolvable by Skill tool
Task(subagent_type: "octo:develop", ...)  ❌ This is a skill, not an agent type
```

### Post-Completion — Interactive Next Steps

**CRITICAL: After the workflow completes, you MUST ask the user what to do next. Do NOT end the session silently.**

```javascript
AskUserQuestion({
  questions: [
    {
      question: "Development phase complete. What would you like to do next?",
      header: "Next Steps",
      multiSelect: false,
      options: [
        {label: "Move to Deliver phase", description: "Validate and review the implementation (/octo:deliver)"},
        {label: "Iterate on the implementation", description: "Make adjustments or handle edge cases"},
        {label: "Run quality gates again", description: "Re-validate with updated code"},
        {label: "Export the implementation", description: "Save a summary of what was built"},
        {label: "Done for now", description: "I have what I need"}
      ]
    }
  ]
})
```

---

**Dispatches to the develop workflow via `orchestrate.sh` for the implementation phase.**

### Model and Effort Policy

- For develop/tangle work on Opus 5, use `high` by default. Raise effort only for a bounded capability-sensitive step; `OCTOPUS_OPUS5_AUTO_XHIGH=1` restores legacy automatic xhigh routing.
- `OCTOPUS_OPUS_MODE=fast` is a recognized legacy preference. It logs a compatibility warning and uses standard subprocess dispatch because Claude's spawned CLI has no supported `--fast` flag.
- Respect `OCTOPUS_OPUS_MODEL` and `OCTOPUS_EFFORT_OVERRIDE`. Treat `OCTOPUS_OPUS_MODE` only as the legacy compatibility preference described above.
- Record durable project memory for autonomy mode, provider availability, frequently used commands, prior project context, and model preferences.
- If Claude Code dynamic workflows are available and the task is a huge single-Claude migration, prefer the native workflow path. Use Octopus develop when multi-provider implementation or validation is the value.

## Quick Usage

Just use natural language:
```
"Build a user authentication system"
"Implement OAuth 2.0 flow"
"Create a caching layer for the API"
```

## What Is Develop?

The **Develop** phase of the Double Diamond methodology (divergent thinking for solutions):
- Multiple implementation approaches via external CLI providers
- Code generation and technical patterns
- Quality gate validation

## What You Get

- Multi-AI implementation (Claude + Antigravity + Codex)
- Multiple implementation approaches
- Quality gate validation (75% consensus threshold)
- Security checks (OWASP compliance)
- Best practices enforcement

## When to Use Develop

Use develop when you need:
- **Building**: "Build X" or "Implement Y"
- **Creating**: "Create Z feature"
- **Code Generation**: "Write code to do Y"

## Part of the Full Workflow

Develop is phase 3 of 4 in the embrace (full) workflow:
1. Discover
2. Define
3. **Develop** <- You are here
4. Deliver

To run all 4 phases: `/octo:embrace`
