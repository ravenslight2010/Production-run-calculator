---
description: "[advanced] Manage the scheduled workflow runner daemon (start/stop/status)"
disable-model-invocation: true
---

# Scheduler

Manage the Claude Octopus scheduled workflow runner daemon.

## MANDATORY COMPLIANCE — DO NOT SKIP

You MUST manage the scheduler only through the installed Octopus scheduler scripts after resolving the plugin root. You are PROHIBITED from:
- Reimplementing scheduler state changes manually
- Editing scheduler state files directly
- Skipping the plugin-root preflight because "I can do this faster directly"

## Usage


**Preflight — Ensure plugin root is resolvable (run via Bash tool FIRST):**

```bash
OCTO_ROOT="${HOME}/.claude-octopus/plugin"
if [[ ! -x "$OCTO_ROOT/scripts/orchestrate.sh" ]]; then
  helper="$OCTO_ROOT/scripts/helpers/ensure-plugin-root.sh"
  if [[ ! -x "$helper" ]]; then
    helper="$(find "${HOME}/.claude/plugins/cache" "${HOME}/Library/Application Support/Claude" "${LOCALAPPDATA:-/dev/null}/Claude" "${XDG_DATA_HOME:-${HOME}/.local/share}/Claude" -maxdepth 8 -path "*/nyldn-plugins/octo/*/scripts/helpers/ensure-plugin-root.sh" -print -quit 2>/dev/null)"
  fi
  [[ -x "$helper" ]] && bash "$helper" >/dev/null 2>&1 || true
fi
test -x "$OCTO_ROOT/scripts/orchestrate.sh" && echo "plugin-root:ok" || echo "plugin-root:missing"
```

If the output is `plugin-root:missing`, stop and ask the user to run `/octo:setup`.


```bash
${HOME}/.claude-octopus/plugin/scripts/scheduler/octopus-scheduler.sh start
${HOME}/.claude-octopus/plugin/scripts/scheduler/octopus-scheduler.sh stop
${HOME}/.claude-octopus/plugin/scripts/scheduler/octopus-scheduler.sh status
${HOME}/.claude-octopus/plugin/scripts/scheduler/octopus-scheduler.sh emergency-stop
```

## Instructions for Claude

This command supports **natural language**. The user may invoke it with explicit subcommands OR with conversational requests. You MUST interpret intent and map to the correct action.

### Step 1: Parse Intent

Map the user's input to one of these actions:

| Intent patterns | Action |
|----------------|--------|
| "start", "run", "launch", "boot up", "turn on" | `start` |
| "stop", "shut down", "turn off", "kill", "halt" | `stop` |
| "status", "how is it", "what's running", "check", "is it running", no args | `status` |
| "emergency", "panic", "abort", "kill everything", "stop all" | `emergency-stop` |

If the intent is ambiguous, use AskUserQuestion to clarify.

### Step 2: Display Banner

```
🐙 **CLAUDE OCTOPUS ACTIVATED** - Scheduler Management
⏰ Scheduler: [action description]

Providers:
🔵 Claude - Daemon management
```

### Step 3: Execute and Present

Run the appropriate `octopus-scheduler.sh` subcommand and present results.

After `status`, give a human-readable summary:
- Whether the daemon is running and for how long
- How many jobs are active
- Current daily spend
- If any kill switches are active, explain what they mean and how to clear them

After `start`, confirm it's running and remind the user to add jobs if none exist.

After `emergency-stop`, explain what happened and how to recover:
- "Remove `~/.claude-octopus/scheduler/switches/KILL_ALL` to allow restart"

### Natural Language Examples

- "is the scheduler running?" → `status`
- "start the scheduler" → `start`
- "shut it down" → `stop`
- "something's wrong, stop everything" → `emergency-stop`
- "what's the scheduler doing?" → `status`
